-- MySQL dump 10.13  Distrib 5.5.57, for Linux (x86_64)
--
-- Host: localhost    Database: ssr
-- ------------------------------------------------------
-- Server version	5.5.57-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `author` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '作者',
  `summary` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '简介',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `type` tinyint(4) DEFAULT '1' COMMENT '类型：1-文章、2-公告',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='文章';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (1,'1',NULL,'1','<p>1</p>',2,1,0,'2018-12-05 01:00:50','2018-12-05 01:01:15');
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '配置名',
  `value` text COLLATE utf8mb4_unicode_ci COMMENT '配置值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'is_rand_port','0'),(2,'is_user_rand_port','0'),(3,'invite_num','3'),(4,'is_register','1'),(5,'is_invite_register','1'),(6,'website_name','JKFUNS-SSRPanel'),(7,'is_reset_password','1'),(8,'reset_password_times','3'),(9,'website_url','http://ssr.jkfuns.fun'),(10,'is_active_register','1'),(11,'active_times','3'),(12,'login_add_score','1'),(13,'min_rand_score','1'),(14,'max_rand_score','100'),(15,'wechat_qrcode',''),(16,'alipay_qrcode',''),(17,'login_add_score_range','1440'),(18,'referral_traffic','1024'),(19,'referral_percent','0.2'),(20,'referral_money','100'),(21,'referral_status','0'),(22,'default_traffic','200'),(23,'traffic_warning','0'),(24,'traffic_warning_percent','80'),(25,'expire_warning','0'),(26,'expire_days','15'),(27,'reset_traffic','1'),(28,'default_days','30'),(29,'subscribe_max','3'),(30,'min_port','10000'),(31,'max_port','20000'),(32,'is_captcha','0'),(33,'is_traffic_ban','1'),(34,'traffic_ban_value','10'),(35,'traffic_ban_time','60'),(36,'is_clear_log','1'),(37,'is_node_crash_warning','0'),(38,'crash_warning_email',''),(39,'is_server_chan','0'),(40,'server_chan_key',''),(41,'is_subscribe_ban','1'),(42,'subscribe_ban_times','20'),(43,'paypal_status','0'),(44,'paypal_client_id',''),(45,'paypal_client_secret',''),(46,'is_free_code','0'),(47,'is_forbid_robot','0'),(48,'subscribe_domain',''),(49,'auto_release_port','1'),(50,'is_youzan','1'),(51,'youzan_client_id','84770c5438e0086a6e'),(52,'youzan_client_secret','8d805c65e3ede2620cc55422bbfcae5f'),(53,'kdt_id','42192598'),(54,'initial_labels_for_user','1,2'),(55,'website_analytics',''),(56,'website_customer_service',''),(57,'register_ip_limit','5'),(58,'goods_purchase_limit_strategy','none'),(59,'is_push_bear','0'),(60,'push_bear_send_key',''),(61,'push_bear_qrcode',''),(62,'is_ban_status','0'),(63,'is_namesilo','0'),(64,'namesilo_key',''),(65,'website_logo',''),(66,'website_home_logo',''),(67,'is_tcp_check','0'),(68,'tcp_check_warning_times','3'),(69,'is_forbid_china','0'),(70,'is_forbid_oversea','0'),(71,'is_verify_register','0'),(72,'node_daily_report','0'),(73,'mix_subscribe','0'),(74,'rand_subscribe','0');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `country_code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='国家代码';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'澳大利亚','au'),(2,'巴西','br'),(3,'加拿大','ca'),(4,'瑞士','ch'),(5,'中国','cn'),(6,'德国','de'),(7,'丹麦','dk'),(8,'埃及','eg'),(9,'法国','fr'),(10,'希腊','gr'),(11,'香港','hk'),(12,'印度尼西亚','id'),(13,'爱尔兰','ie'),(14,'以色列','il'),(15,'印度','in'),(16,'伊拉克','iq'),(17,'伊朗','ir'),(18,'意大利','it'),(19,'日本','jp'),(20,'韩国','kr'),(21,'墨西哥','mx'),(22,'马来西亚','my'),(23,'荷兰','nl'),(24,'挪威','no'),(25,'纽西兰','nz'),(26,'菲律宾','ph'),(27,'俄罗斯','ru'),(28,'瑞典','se'),(29,'新加坡','sg'),(30,'泰国','th'),(31,'土耳其','tr'),(32,'台湾','tw'),(33,'英国','uk'),(34,'美国','us'),(35,'越南','vn'),(36,'波兰','pl'),(37,'哈萨克斯坦','kz'),(38,'乌克兰','ua'),(39,'罗马尼亚','ro'),(40,'阿联酋','ae'),(41,'南非','za'),(42,'缅甸','mm'),(43,'冰岛','is'),(44,'芬兰','fi'),(45,'卢森堡','lu'),(46,'比利时','be'),(47,'保加利亚','bg'),(48,'立陶宛','lt'),(49,'哥伦比亚','co'),(50,'澳门','mo'),(51,'肯尼亚','ke'),(52,'捷克','cz'),(53,'摩尔多瓦','md'),(54,'西班牙','es'),(55,'巴基斯坦','pk'),(56,'葡萄牙','pt'),(57,'匈牙利','hu'),(58,'阿根廷','ar');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon`
--

DROP TABLE IF EXISTS `coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '优惠券名称',
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '优惠券LOGO',
  `sn` char(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '优惠券码',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '类型：1-现金券、2-折扣券、3-充值券',
  `usage` tinyint(4) NOT NULL DEFAULT '1' COMMENT '用途：1-仅限一次性使用、2-可重复使用',
  `amount` bigint(20) NOT NULL DEFAULT '0' COMMENT '金额，单位分',
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '折扣',
  `available_start` int(11) NOT NULL DEFAULT '0' COMMENT '有效期开始',
  `available_end` int(11) NOT NULL DEFAULT '0' COMMENT '有效期结束',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否已删除：0-未删除、1-已删除',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态：0-未使用、1-已使用、2-已失效',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='优惠券';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon`
--

LOCK TABLES `coupon` WRITE;
/*!40000 ALTER TABLE `coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_log`
--

DROP TABLE IF EXISTS `coupon_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupon_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL DEFAULT '0' COMMENT '优惠券ID',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品ID',
  `order_id` int(11) NOT NULL DEFAULT '0' COMMENT '订单ID',
  `desc` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='优惠券使用日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_log`
--

LOCK TABLES `coupon_log` WRITE;
/*!40000 ALTER TABLE `coupon_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_log`
--

DROP TABLE IF EXISTS `email_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '类型：1-邮件、2-serverChan',
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '收信地址',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内容',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态：1-发送成功、2-发送失败',
  `error` text COLLATE utf8mb4_unicode_ci COMMENT '发送失败抛出的异常信息',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='邮件投递记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_log`
--

LOCK TABLES `email_log` WRITE;
/*!40000 ALTER TABLE `email_log` DISABLE KEYS */;
INSERT INTO `email_log` VALUES (1,1,'599948174@qq.com','注册激活','请求地址：http://ssr.jkfuns.fun/active/1b235f3fce3b310c886e33b29c0b5942',0,'Failed to authenticate on SMTP server with username \"931512501@qq.com\" using 1 possible authenticators','2018-12-04 16:05:57'),(2,1,'599948174@qq.com','注册激活','请求地址：http://ssr.jkfuns.fun/active/8166727a05d0d9080dffe21a5e5ce827',0,'Failed to authenticate on SMTP server with username \"931512501@qq.com\" using 1 possible authenticators','2018-12-04 16:09:45'),(3,1,'599948174@qq.com','重新激活账号','请求地址：http://ssr.jkfuns.fun/active/78810ead78dcc9c2c1c2e7c59bb7c770',1,'','2018-12-04 16:13:09'),(4,1,'931512501@qq.com','注册激活','请求地址：http://ssr.jkfuns.fun/active/9d31bd507769163dda614250cf7ba85c',1,'','2018-12-04 16:19:36'),(5,1,'1756704416@QQ.COM','注册激活','请求地址：http://ssr.jkfuns.fun/active/baeeac7213215d07d64abf69267f5b28',1,'','2018-12-04 21:52:33'),(6,1,'314670899@qq.com','注册激活','请求地址：http://ssr.jkfuns.fun/active/970993663c36b4646531320b377000c0',1,'','2018-12-04 22:22:44');
/*!40000 ALTER TABLE `email_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods`
--

DROP TABLE IF EXISTS `goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '商品服务SKU',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '商品名称',
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '商品图片地址',
  `traffic` bigint(20) NOT NULL DEFAULT '0' COMMENT '商品内含多少流量，单位Mib',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '商品价值多少积分',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '商品类型：1-流量包、2-套餐、3-余额充值',
  `price` int(11) NOT NULL DEFAULT '0' COMMENT '商品售价，单位分',
  `desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '商品描述',
  `days` int(11) NOT NULL DEFAULT '30' COMMENT '有效期',
  `color` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'green' COMMENT '商品颜色',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `is_limit` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否限购：0-否、1-是',
  `is_hot` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否热销：0-否、1-是',
  `is_del` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否已删除：0-否、1-是',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态：0-下架、1-上架',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods`
--

LOCK TABLES `goods` WRITE;
/*!40000 ALTER TABLE `goods` DISABLE KEYS */;
INSERT INTO `goods` VALUES (1,'S00001','JP','',1024,0,1,0,NULL,30,'green',0,0,1,1,1,'2018-12-04 15:59:12','2018-12-04 16:23:09'),(2,'S00002','日本1GB流量套餐','',1024,0,1,500,'日本1GB流量套餐',90,'green',0,0,1,1,1,'2018-12-04 16:24:10','2018-12-04 21:02:32'),(3,'S00003','100M体验包','',1024,0,2,10,'100M体验包',90,'green',0,0,1,1,1,'2018-12-04 16:35:05','2018-12-04 21:02:26'),(4,'S00004','10M','',10,0,1,1,'10M',30,'green',0,0,1,1,1,'2018-12-04 16:59:12','2018-12-04 21:02:21'),(5,'S00005','日本1g套餐   100m带宽','',1024,0,2,300,'日本1g套餐   100m带宽',300,'green',0,0,0,0,1,'2018-12-04 21:03:08','2018-12-04 21:08:51');
/*!40000 ALTER TABLE `goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_label`
--

DROP TABLE IF EXISTS `goods_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_label` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品ID',
  `label_id` int(11) NOT NULL DEFAULT '0' COMMENT '标签ID',
  PRIMARY KEY (`id`),
  KEY `idx` (`goods_id`,`label_id`),
  KEY `idx_goods_id` (`goods_id`),
  KEY `idx_label_id` (`label_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品标签';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_label`
--

LOCK TABLES `goods_label` WRITE;
/*!40000 ALTER TABLE `goods_label` DISABLE KEYS */;
INSERT INTO `goods_label` VALUES (3,5,1);
/*!40000 ALTER TABLE `goods_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invite`
--

DROP TABLE IF EXISTS `invite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '邀请人ID',
  `fuid` int(11) NOT NULL DEFAULT '0' COMMENT '受邀人ID',
  `code` char(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '邀请码',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '邀请码状态：0-未使用、1-已使用、2-已过期',
  `dateline` datetime DEFAULT NULL COMMENT '有效期至',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='邀请码表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invite`
--

LOCK TABLES `invite` WRITE;
/*!40000 ALTER TABLE `invite` DISABLE KEYS */;
/*!40000 ALTER TABLE `invite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `label`
--

DROP TABLE IF EXISTS `label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `label` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '名称',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='标签';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `label`
--

LOCK TABLES `label` WRITE;
/*!40000 ALTER TABLE `label` DISABLE KEYS */;
INSERT INTO `label` VALUES (1,'电信',0),(2,'联通',0),(3,'移动',0),(4,'教育网',0),(5,'其他网络',0),(6,'免费体验',0);
/*!40000 ALTER TABLE `label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `level`
--

DROP TABLE IF EXISTS `level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) NOT NULL DEFAULT '1' COMMENT '等级',
  `level_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '等级名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='等级';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `level`
--

LOCK TABLES `level` WRITE;
/*!40000 ALTER TABLE `level` DISABLE KEYS */;
INSERT INTO `level` VALUES (1,1,'青铜'),(2,2,'白银'),(3,3,'黄金'),(4,4,'铂金'),(5,5,'钻石'),(6,6,'星耀'),(7,7,'王者');
/*!40000 ALTER TABLE `level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing`
--

DROP TABLE IF EXISTS `marketing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) NOT NULL COMMENT '类型：1-邮件群发、2-订阅渠道群发',
  `receiver` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '接收者',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标题',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内容',
  `error` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '错误信息',
  `status` tinyint(4) NOT NULL COMMENT '状态：-1-失败、0-待发送、1-成功',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='营销';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing`
--

LOCK TABLES `marketing` WRITE;
/*!40000 ALTER TABLE `marketing` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `oid` int(11) NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '订单编号',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '操作人',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品ID',
  `coupon_id` int(11) NOT NULL DEFAULT '0' COMMENT '优惠券ID',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  `origin_amount` int(11) NOT NULL DEFAULT '0' COMMENT '订单原始总价，单位分',
  `amount` int(11) NOT NULL DEFAULT '0' COMMENT '订单总价，单位分',
  `expire_at` datetime DEFAULT NULL COMMENT '过期时间',
  `is_expire` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否已过期：0-未过期、1-已过期',
  `pay_way` tinyint(4) NOT NULL DEFAULT '1' COMMENT '支付方式：1-余额支付、2-有赞云支付',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '订单状态：-1-已关闭、0-待支付、1-已支付待确认、2-已完成',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后一次更新时间',
  PRIMARY KEY (`oid`),
  KEY `idx_order_search` (`user_id`,`goods_id`,`is_expire`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,'181204155925926563',1,1,0,NULL,0,0,'2019-01-03 15:59:25',0,1,2,'2018-12-04 15:59:25','2018-12-04 15:59:25'),(2,'181204163237571054',4,2,0,NULL,500,500,'2019-03-04 16:32:37',0,2,-1,'2018-12-04 16:32:37','2018-12-04 16:48:03'),(3,'181204163531535029',4,3,0,NULL,10,10,'2019-03-04 16:35:31',0,2,-1,'2018-12-04 16:35:31','2018-12-04 16:51:03'),(4,'181204164249665952',3,3,0,NULL,10,10,'2019-03-04 16:42:49',0,2,-1,'2018-12-04 16:42:49','2018-12-04 16:58:03'),(5,'181204165108429218',1,3,0,NULL,10,10,'2019-03-04 16:51:08',0,2,-1,'2018-12-04 16:51:08','2018-12-04 17:07:02'),(6,'181204165933160788',1,4,0,NULL,1,1,'2019-01-03 16:59:33',0,2,2,'2018-12-04 16:59:33','2018-12-04 16:59:52'),(7,'181204222324547987',7,5,0,NULL,300,300,'2019-09-30 22:23:24',0,2,-1,'2018-12-04 22:23:24','2018-12-04 22:39:02');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_goods`
--

DROP TABLE IF EXISTS `order_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_goods` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) NOT NULL DEFAULT '0' COMMENT '订单ID',
  `order_sn` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '订单编号',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品ID',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '商品数量',
  `origin_price` int(11) NOT NULL DEFAULT '0' COMMENT '商品原价，单位分',
  `price` int(11) NOT NULL DEFAULT '0' COMMENT '商品实际价格，单位分',
  `is_expire` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否已过期：0-未过期、1-已过期',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_goods`
--

LOCK TABLES `order_goods` WRITE;
/*!40000 ALTER TABLE `order_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sn` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `oid` int(11) DEFAULT NULL COMMENT '本地订单ID',
  `order_sn` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '本地订单长ID',
  `pay_way` tinyint(4) NOT NULL DEFAULT '1' COMMENT '支付方式：1-微信、2-支付宝',
  `amount` int(11) NOT NULL DEFAULT '0' COMMENT '金额，单位分',
  `qr_id` int(11) NOT NULL DEFAULT '0' COMMENT '有赞生成的支付单ID',
  `qr_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '有赞生成的支付二维码URL',
  `qr_code` text COLLATE utf8mb4_unicode_ci COMMENT '有赞生成的支付二维码图片base64',
  `qr_local_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付二维码的本地存储URL',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态：-1-支付失败、0-等待支付、1-支付成功',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,'GBNEPdsc3Ztk',4,2,'181204163237571054',1,500,9887679,'https://trade.koudaitong.com/wxpay/confirmQr?qr_id=9887679&kdt_id=42192598','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOwAAADsCAIAAAD4sd1DAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAMRElEQVR4nO2dP28kxRbFe8b4beJBICIsYRGxpGQOCOczrESMtAkBIV+ElA8CS0KAtBFEKwHRykjOhhWs3j75rT1NYGENs/Onqu49t+4Zn1/kXXVXVfecmT51+9atyTiOgxDMTHsPQAgrErGgRyIW9EjEgh6JWNAjEQt6JGJBj0Qs6JGIBT0SsaBHIhb0SMSCHolY0CMRC3okYkGPRCzokYgFPRKxoEciFvS8ZTl5Mpl4jWOVjcv+Cvvau2RwrZ2743e0v+2YqnN3jMHr3JLj915Lw7leNC/31C+xoEciFvRIxIIekydG4+W9drRT0oVlGF7nVvnFhusF2dwYPEXcbMy9Jm2FWCZz3XEsduN1jejPfS+yE4IeiVjQA/HEaHtgfAyhfXAYJbHeSIJt4R2pJ3bdP5Vb9nrHknFGfitWx1PSb+3x2ZCdEPRIxIKe1HZilY6PueauHcdc6+OTOLEYaES8g+ZEmeA4MWIi6+LXd0DxZZCdEPRIxIKeQ7AT3aNChQPY+8RviPt2v/YMsIrYxbOWxEcTmkJoXkfC692L7ISgRyIW9KS2EyDDVxJP3XtMQAzYPRe5V24DGoiIQXdhY7MJZz+1i1U3ntswyeueA91L/bITgh6JWNDjaSfCnmKWWgq7m3I82Hc8XfIiCsffPVademIHwlIMxXI8ejxe/dIhOyHokYgFPUx2wmhJm9thofZ6D+b+mERMFBWv8n/brqv2er2O71hrojk2H4nshKBHIhb0hHrigFwIKMa8YURfaGpzMJrrQ1vIPrFzL5qdzc8Zac7TSPvmogHZCUGPRCzo8dyzw5LDUNJFiSeryj1I8ujsPgyE12/Iu2jWSagn3rGmDZF43iv3wKsgtvs6QsvplskcGtkJQY9ELOiJsBO96gGjvSbCI9a2X+L10fnW3es998ydaPZbXvV0HbPm0fuJRE5G0fnW7h5adkLQIxELeiBxYgTo2POOvprbNLbjRa8847D4N7zuhCV/t7avVTp6ym24pBcb5wPNk7/ub2R2IDsh6JGIBT0pUjG9HmFeORVJyBA7R4/hXuQTW2j2ebU+24KXx21os/Zcl4R3xLdCdkLQIxELelC12LziuJaDs9VbyJzTXELa8afwxCU+LLg+Wi/QPrLqxwWx5zNi9iw7IeiRiAU9KDsBrfu745RIFwHtCxTQ3RtVBOWobKN/nLg2HhnsUy39hu3tXPgpuqSXIHKvEb65FtkJQY9ELOjpGWJLtQbO8dzaNmtXSXUPI0bmkZfgJuKqjdYGWz5DQyzZZW85y7kZ4tbd1XaL1tgJsY5ELOjxXGO3Dff95BrOdfGUoLoNtTS3mWTp0eHkE4Pii10+mIZav83r7QLqYOw91xLbVj6xEBuQiAU92ffsQKQQuD/RvBpsyI1GtOme84C2dhG5E7VNebW5sX2LpwyOs4bVMgtGcWIh1pGIBT0Z6xMjHpdpY6uOnrVLeBHh42uJjhMjcny9/HSVD3YvSFwIKDcaXZMYiuyEoEciFvRE5E6gm0XUu8gZxtp9Zyxx3wCLv/eY5nvu6Ykt3rTKSzXEp1Pl9RpBXwt6/xF3ZCcEPRKxoAcSYgvIkcjW/iFRMjfokqOyjYh97LJNkixr5vqyNnLEukPQGseqMdQiOyHokYgFPVlyJyL7iowHj4vF/7/5ZhiG40ePph9+aGzN906i60DHMQKwDKN2qK3XvadNr1vx6osv/hiGP4bhz4cPr3/6ydia/X6WNGXsunwMXshOABkXi9fff3/7982vv14/edJ3PIeKRAxkfPly9Z/Li4teIzls3Dyx0Rh197IIYze+eDFeXro3awFdN7oLERO7MTBvYVtfkWO44+bZs+XKj/H07My9i73XNWLiu1W4/+KsITsB5Obp09V/Tk5Pe43ksJGIUYyLxc1vv63+z+Ttt3sN5rBJsQVYA/nt2vLiYu2XeJ2rq2EYhgcPoMMA1Z2wjGGv5asFUp/Yq15YBl/bzPWTJ8t/Ryeuv/tu+sEHy99/X/7yy/Li4vZ3+ng+f/Dll1VS3njfjL6z5N7Wfl5hTBCm2+ubZ0lqqR2Db4GScbH472efvX4jMDydzYZh+NdsbzY7+eGHo08+KWn2dpBVY3NcNOD1eeX9JRarXP/440YvsfbbLFxIIeLCbyQihxXxBFw+f3719deFep2cnk7efdd3AOh87mxltQ4hOlH1fn/1nTtiMDc///zq8eM3jYTAkeKXmJpxsVheXNw8ezZeXv7n88//99VXVQoeLy/HFy8Gc4LbfUYiNrF8/vzV48c3T58uX748evjw+NGj3iO6j9wXEYOiP7fBYMt0bXJ6Wvs62mX/kQA41th5UW5nyw8A1Sxz53g+n5ycuDeLCMO1NR7AIUzsqFl7NS0akIgFPRH5xO7v6KlfR69xPJ9b0ici47tpb28KTwxi44eUKlA/nc2Ozs87DmAjXj8KVXMYC7ITnZnMZr2HQI9E3JOj83PEco/7BpOdQOS/hlbln82GfwLDRx99dHR+/tann07eew/Rl6WeGjqfeBUXRxG6xq4WRG0vYyy5nFXJHs/nt39MZrPp2dnk5MQrF77E90e232WOwfRLnJA7RzudzW6NwfF8fjyfTz/+ePLOO7eqdZSs2IhbUjzi24musugw5qur199+O/711/TsbHp2Nn3/fahe3xxwVQTG6356VdrcdnwtJhGDborLTUeHh7rQJmIL6Bg8jSduptC/5hQcAt8r9Wqt+8smhdgEPRKxoCfaTlTVUyt8PKV9p+/O2mrngM3nSixH9/vvtmeHZXLWYM5qP0j0hDIb7hM+RF0RL2QnBD0SsaCnZ4ity1M79d4TB8qhVQBy8bKO7XPhVXDNcRgZ8rNlJwQ9qd/YdaR5AXBDscOq9sWboETslavqtU8H2l2EuZdu5VMT27Mse3agE1mq+q2l1hc6ekrEL3SGMVQhTyzokYgFPRFJ8ew0hwWT5PV6Vc9HjG1jO7VA9uxYBTRbL2kn7R4Ta7DEtqFfTguyE4IeiVjQY7ITyWt7ecWYLf1m4GBi5NvI8sauytcmiR+75yiX5OyG1c0Ymr75yp0QogWJWNDjaScQNdEQy8iyhcZr66ahH9klTqa2EeiYUWvsqk4HZXX1ir9uHBvCy1pi8179dp/VDbIT4gCQiAU9nnHibITV3y1s36uGQ+aUYss97587YSGgQkdzTnNJm6t4xYMHpzlDZCVM1WITohGJWNCTwk5YHvGOj7DmWCzoMYpotqrN5HOeO9zixNvIEKMtOR5dM85xPFV5Jo41nveOrVcGmOyEoEciFvRA8olBPtVyYvdl5QFs9PQNNZ5r32Y3F5rxIsXELnJvDlI1Q+tL9Mpd9roo2QlBj0Qs6OmZT+zld6vaLPTKez0iaD+RyIhkicelcF/wPTu24fguvvu7+zWyjacElxgwej6zDdkJQY9ELOiJrk9seSr1yg/OQK8c6JLYc7NVYN2z446G9WFVzdZ+i9CFfhvqabjsb2LZf677W4xCZCcEPRKxoCfFGrsAU+vyZHSMDUNjsaC8kdo5SVgJstA9Oyzn1vrFbLURLATsG9fLzqo+sRDDIBGLAyBFKuYOLDFjr33vej1qLTm+Lp06NsVRiw3RDsjLNud1FI6Tbq8Qr+OhFVJ2IDsh6JGIBT0p4sRrhNUPNib71j5eg10TjoYwn9cq/41kn9itErmvB0UyeC21G5GwfLtkJwQ9ErGgh8lObAOxjq1LjBYEyzib8RSxV3K0F801idF7amw7LKAGswvG63Kfb8hOCHokYkEPxBNbltMEg3i/n7nWhAWv63KPGVNO7GpnWr3W81naLDnAmEvNkuOxF9kJQY9ELOhhshOW+rte/WYm254jYaQWca/3+KA1bWELJ2vH4Hj8HZGTe9kJQY9ELOhJbSd2AH0KW+of47q+w+UR7LWXR4a9UVhFvEqGesDNHx5j/m4JkVlTshOCHolY0HMIdsJSW7ekHcsYtoH2johazrU51mE2DyLiAHffXKPN2E6k/+7l9TPMMaqQnRD0SMSCnp772EX2hc6FbaZjTNpC7TrFkmPuVz5xCY7xV/c1cAF9leCSuzwk8NCyE4IeiVjQIxELeiYZVmsKYUG/xIIeiVjQIxELeiRiQY9ELOiRiAU9ErGgRyIW9EjEgh6JWNAjEQt6JGJBj0Qs6JGIBT0SsaBHIhb0SMSCHolY0PM3Djy3UBmn5qIAAAAASUVORK5CYII=','/assets/images/qrcode/20181204/960088435179480565.png',-1,'2018-12-04 16:32:38','2018-12-04 16:48:03'),(2,'T94rQKVKUUus',4,3,'181204163531535029',1,10,9887739,'https://trade.koudaitong.com/wxpay/confirmQr?qr_id=9887739&kdt_id=42192598','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOwAAADsCAIAAAD4sd1DAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAMLUlEQVR4nO2dP28TSxTF1w55FC9GICoiEVEBLV0KSn8GJGokKiRKvgiU1HwG/jQUSHRUSECFgpTOQgK9x8uD2K+IXmQcOzt37p+5xzm/CszuzHh92D1z986dwWw26whBZth6AIRooYgJPBQxgYciJvBQxAQeipjAQxETeChiAg9FTOChiAk8FDGBhyIm8FDEBB6KmMBDERN4KGICD0VM4KGICTwUMYHnnObkwWBgNY55jpf9LbRvvhxwVfuFn1sds/R7VYyht9+S9p3GUEL178s7MYGHIibwUMQEHpUnDmaVFUMvneFkMUXte4/BFUsRV4upRJ2RV3nVFyn5gtJjDL+X98Srt18pVuOknSDwUMQEHhdPXPiY6H0MWT1unNrRxH2VXefE6neXgjSx85jAZZgUal6yiNovAeJ/ywK0EwQeipjAg2QnjjH0XvNNSb1s7zAKx7nqMO8pQQYrZUJqEVtdZcO4rCY5yTtJaOnBkX66FbQTBB6KmMCT2k4Ex4l7/fEpTXnnJ5SMLUObTUgt4lMwj6E2jI8uFVCJr9XkcqzTbI92gsBDERN4UO1ECShvUJd608L4tNXaOGh/7CJij/iu9JjgRY4lQzpGs9gzc/5xK/XTThB4KGICj6WdMH9SG9aFkMZ3Tb5LxatpzTjD6nKcflg86zyxk4re6vNW4zyz0E4QeChiAg+SnWiVd2t1vBT09sNQibhhVFyUd1tSR0LaTokCpNfHKg/Y+3fJ9jaEdoLAQxETeJp54pIlOobtVy8rMoz1+p148nTXMJx3yFJK6oldNu81T6s6ccoxrGWMmXaCwEMRE3jM7IRyP4uSNjU5ElKa5CoUErmeL/Lzalp64iYi0MSMpevSpJNXZYZN2IY9FWNwhXaCwEMRE3ha7mMXuWpcE0OVejtNKdWw7+5Ek8idy54dGfaMyBAH9d6bQ9OvNG+kYpId9rvQThB4KGICT0SI7azlxZp4UGUw2GQ9XLYLu4rofGLRKYazkOrUXivPp9kbT0OhL7faoq8JtBMEHoqYwGMZJ7bKtfV4fRqQVtt7jCh05d1vRePSNsMsdcTErnn8WJOc1CpvWOplNfXdSo4xvD7m3pp2gsBDERN4kOLEkb42ssaZd1Nheb2tyLLGziqOa1IvorfTQpxUotnrrjr+LRpYMLQTBB6KmMCTpT6xqz9zynueJ8PeclY+vjoOrXxFn67uhFWAvXp9WyGuOa/SfAlpv4YxbOh6FLQTBB6KmMCTJcS2iur1bcGPxWqP6DTO5rUgItt3WWOnOTGDJ2u4w0rkNTSJN/d+WD6eamgnCDwUMYHH3RNXPKqa0NBDt8Ikb6TitbY5GSd20guRwZ+Z5OZqGi85PkM83qNYDO0EgYciJvBE2wmP2roZYsYeOdPS+YPHfMPKXeSNE0uLFVR4subr80oAzVtwTf+V1nrTQDtB4KGICTzudSeUNYBb0Wo9n8lgvI8/5RRNrbd0+cSrMImVSr98hXdPVXds4aJZhY0ruq4+xhXaCQIPRUzgyRgnlh6vqe+29BgUNJ7ScK7SfD7TMk6cNhkoLYUydfrfaF73zWqctBMEHoqYwOO1t3PJo4fOoYKAGLAHThmeR2SME7vWFIObvcVjEleeh2vsCOmBIibweNkJkyeIlZ/2TgU8hdlk8u/Tp13Xbd65M7x2Tdna6d/a/KmtzKkIu85mSQKRtQ48+lro1+qy/Hjw4J8nT7qu27hx489nzzZu3dK0tpA7YRWvbXWdraCdcGQ2mfx89eroz4cfP/56+bLteNYVitiR2ffv83+d7u21Gsl6Y5lPrDklcu2da8zytwa/fp3t79u22aUJ/R5jlQ+dOp84Mt801Vq9w/fvp3M34+HOjrLB2WyW4Xtlg3bCkcO3b+f/OtjebjWS9YYi9mI2mRx++jT/yeDChVaDWW+Q9rHDYrq3t3AnXuTgoOu67vz5mPEsAFSLoxeX+sRWRt4jgT2sFvKvly+nv0cnfr14Mbx6dfrly/TDh+ne3tF9enM8Pv/wYbmUK764NO27+hhNXRENqqi+VZC8sH3NudIgv7Z+3mTy1927P08EhoejUdd1v832RqOt16+VL0E6u4Qq6THSMXiIOGNVzDXg15s3S73Ewr2ZmJBCxAFrxaqPr2D6+fPB48eFeh1sbw8uXSpsuW7J/sLpvf9k8pSrGFKbOHFwbq5Hd+Y5x4fv3v149OikkQjmTKVNp7gTQzObTKZ7e4fv38/29/+4d0+q4Nn+/uzr106d4HaWoYhVTD9//vv+/cO3b6ffv2/cuLF5507rEZ1FvNbYobDUk5VHJ46CwZrp2mB7u/p1tNM1j6xDZ0Lo3s4emTfo5m9zPB5sbcX0VVIDRFSJRjkMK2XztXNjFl5NkwooYgKPVz5xZH7wPHClsTbHY2n6hObaanZGs7qM5j9Hy9wJMhyNNnZ3y48/mU9cjZU/LumCdSfWnMFo1HoI8FDELdnY3dUv9yCWdiKDi9C8i3d/6o1G3f+B4Y3r1zd2d8/dvj24fNm101Uwn7gf6Vo3TdKPaF/isCs7L9nN8fjoD4PRaLizM9jaapULv4reHBJD32zulfnaWcWxox2ORkfGYHM83hyPhzdvDi5ePFJtQsmuGZZJ8fNkuBNrwm2l4zk4+Pn8+ezbt+HOznBnZ3jlirdenSIG1emXhnfi+hTTJCLW4LFNVdq32cETjyblFqSE7tmx6nOPPSBS+eOzg/TpZ3KzYIiNwEMRE3iia7HN42THe49P63d7of9ZSooQW5K97hBzP6wiM5pYe+9NwfuuQTtB4KGICTwt7YQ0hzV4ZwYiRfoSyuplh1mcWLm/g+gYp36Xtk/yQztB4EkRnUDE6hHJyu96WsaJs3WnqShQsj+Iph0pVusXPfKz12eNnaHvFN0Fs+VONBxP9V2/Ih/G9QlDT0zgoYgJPNFr7FbVPps/xiMerHmcrUfexUmqn+wVqZXrX4stCdX146z8n1V+QsV4zD1rpD+mnSDwUMQEHveXHcp6bQHDEB1c4o97+9J8caWnN2w2Dy5x4pJjpDFdzXicJo6ZiawLUX09rX4I2gkCD0VM4MlSi63XayY0bQmHZII050Eaj9fkqCxl3bLYXPe6i4yzdkbzhGzxYw9oJwg8FDGBJ6OdMHlyWSXUxpze26bm0d+qvkcYXmvsqq2bkz9LFRuOzI43pHqVije0EwQeipjA0zJ3ouIwW7I9spV5Jpr4bgnS+K7VqqdezERcMQKrQtxWeRfeObvV40Hpq9V6QdoJAg9FTOBpWXfCw6uV5F2UeDjpI9sjZzesbgM6ES87RMKKrB1htW+IoWetLsLnsc7PCfMuaCcIPBQxgSdL7oR5LbCAtX2RntU7Bqw/sfzcXPnEhrkT3ohyM3o/PNlO5roNKIsMqqGdIPBQxAQeL09s7ntKGj/lnzRxXM26MSlhecnrRLOJnWFObWSNhZJzw9bblRzv5H2txmPyn4p2gsBDERN4UuzZ0TA8F5nzoME77yLDd6ymWe6ER4MesdWGv5bVGCK9exNoJwg8FDGBJ0vuRAnSFTLefXnjPYYM39EEs9yJDO1I+9LkNBd2sRRNTbTCNj0wGYPHb007QeChiAk8KeLEC7jWDlPmXWhympvs8eZBhd1ydRqpJ3bKX12zh8hZBu6a0E4QeChiAk9qO5EwSbdVbi7Kk70J0fvYLcWq3rCHV65oX9TRqlOs8iVWfWhVr0N6isf/RtoJAg9FTOBx8cSGj3WPYVjlEEPUSqsYjMf3cr0mqSd2Ug/nVFtNekx1v70fnuw3c0w3bGy0EwQeipjAk9pOnIKmlrBVvxnazOzLw8aAKmIporiv1I+WtLmqi2C1me8FaFVHWQPtBIGHIibwnBU7cUxhPnFk/bVIWsV6zXO150EVsfnedZF133o/XKBhDQ2TvT+8Y9u0EwQeipjAg2onpLWEpU7DO39gXUtLNRm2i4g9Mnu89w2uaN9qIxyrvnqP0VxDq7wUD2gnCDwUMYHH0k5ktnGucUpppxWnmIxTOZ60+31ATuykBjFJrWLpurcm+2547F3iDe0EgYciJvBQxASeQVq3TkghvBMTeChiAg9FTOChiAk8FDGBhyIm8FDEBB6KmMBDERN4KGICD0VM4KGICTwUMYGHIibwUMQEHoqYwEMRE3goYgLPf+/xwZK6kltdAAAAAElFTkSuQmCC','/assets/images/qrcode/20181204/628760347200317283.png',-1,'2018-12-04 16:35:31','2018-12-04 16:51:03'),(3,'vKcaCaQw6gqc',3,4,'181204164249665952',1,10,9887879,'https://trade.koudaitong.com/wxpay/confirmQr?qr_id=9887879&kdt_id=42192598','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOwAAADsCAIAAAD4sd1DAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAMO0lEQVR4nO2dMW8bRxCF76gobkQjQaoIsJDKTutORUr+BgOpA7hJ4dJ/JG1+iKM0KQK4cioDSSpDAdQxRmLEgWKJTEFEuFA8cmdnZmce/b7Kpu52l8dH3tu52dl+uVx2hCAziR4AIVooYgIPRUzgoYgJPBQxgYciJvBQxAQeipjAQxETeChiAg9FTOChiAk8FDGBhyIm8FDEBB6KmMBDERN4KGICD0VM4PlAc3Lf91bjGLJx2V9hXzuXDK61c3P8lvZLjtGMQdROyTi3HD/2XjTnWlG93JO/xAQeipjAQxETeFSe2BuN9yo8t+Sw6mEovePwdJFf3NLv2J+cbG4bLEVcbcyVV1Dar2ZyYzWGagw7spqoRX3uN9BOEHgoYgKPiydufAuW3pVcfaG3uZTGiVsSZb1ST+zG3q30Yll5vhIPrcRkzMOBlbQjPT4btBMEHoqYwJPaTgwJvM1luMNK49nh/rglMCLeglWc2INqMW3xqaLxK9UM8WWgnSDwUMQEnn2wE+GetSJXYQjELTszMCK2ihmPvdggBmyOR3wX4o2vQTtB4KGICTyp7YSh2R1rKjyNsBuJ7xb67BKXZb5GMBsuIm58FUwWZnrk6Y5R8QXYKcQM+Q9R6qedIPBQxAQeSzuRLV5bcncr8Y7Vj6mV45G+bn43Lxx/+OeeemK3hnd+cLZ2zL9Uhf3CQTtB4KGICTxIdsLqrpft7un9vqxeT4tKxIFRcVHXmjVn1Z1WHO/dTmf04CPb0xDaCQIPRUzg6VveGhqbLfOyVHBm8TaasJqolvMYHimv2Sd25skraSP2ekRfvH26DrQTBB6KmMDjtWeH1SNNTbqCyWNbxNurFMNazmMHi/KepbT2xOabsgSKrDrnYQyP3AmruhOZCxnSThB4KGICT4oQm5MliCoVLMr9VdasKDlRU5rWatrg+lm4505UGKZm9YAT7n+xs/2dLxr2pcxjbvY50k4QeChiAo9lnNhqr7WSUzS3pJ3tKMfWDOUaOO8842bXJMXErpPXStt+4u3jQ2oSK71gyz1BvNfzuUI7QeChiAk8kfvYjZ1iVeeh5E+Z97nwuINn8LXm1zyLJ/ag2udJfbYGZQ216rlExbkmCe8e3wraCQIPRUzgyViLTZO3WvKnqHoLJr4/kLTj9/LEVvFIq+f1KHj7SNd6HeYDKIR2gsBDERN4WofYvJ/Lt3QRrn05BXR3RhUNw4gNVk+tMMsnLom5Nn4u710opLrNnS9WH7b9XM17KalPFzUPoZ0g8FDEBB4vTxy+7krZfsu8hWqrEHX79l5uJMVMxNLn9Zp8hgpvral3YXJuhrh1uNpWcI0dIetQxAQer1psgU3tbD/DvnTVGBr9KKsDmU+syXmt7qjlB1NR67e6jrJySCbnamLbzCcmZAMUMYGnae6Edz2HqJpuTonUJn7RMN96iHeNERHuuRMVTVm1ubP9ithzeKg1fAB6GCcmZB2KmMDTwhNL8yiktxtNnkZ43oJh3nBI3LfCc5sTtmdHkhzf240rX7fq1xBRbgniGkfaCQIPRUzgyZI70aBZUaeIkSxN3LelxTefn1h6Yk2st3pvtsxezYMG+SHmdt/7mtNOEHgoYgJPxvrEHqC7iJaUxOwzrKG8wX0fu/LDYslQP0GKx7rDxvVDTLRBO0HgoYgJPFlyJ6IwX++1xnI+/+fbb7uuO3z0aPLZZ/oGo9Y1ZsiRGGXpgGYY0qEa9jV83epSvP3669+77veu++PBg6sXL/QNGr7HnedW9CsagxW0E44s5/N333+/+vf1L79cnZ3FjmdfoYgdWb55M/zv4vw8aiT7jZknVhoj75zjkr7Mvd3y9evlxYVtm0oyrFk0p2ndCe884Ab5siKuX75cDH6MJycn5l3sHP+W6+P63sfG4AHthCPXz58P/9sfH0eNZL+hiL1YzufXv/46fKW/ezdqMPsN6ra4+e3a4vx87Zd4ncvLruu6O3fK27RNSmk2N/Auh9C6PvHYKRtJUgCvjquzs8X/oxNX3303uXdv8dtvi59/Xpyfr36nD2ezO0+eiKS88bopfWfJtZV+Xs3oPUy31TfPI9GkTZGU5Xz+15dfvrsVGJ5Mp13X/W+2N50e/fDDwcOHJc2uBikam+GiAavPK+8vMRly9eOPG73E2m8zMSGFiAu/kS330dCwePXq8ptvCvXaHx/3H39sO4DGNe+8I2g72YfohOj5/vCZu8dgrn/66e3jx7eNBPEjxS8xNMv5fHF+fv3y5fLi4sOvvvr76VORgpcXF8vXrzuLBLf3FopYxeLVq7ePH18/f7548+bgwYPDR4+iR/Q+8r6I2Cn6swoGa6Zr/fGx9HG0yf4jDcBYY2dFuZ0tPyBbrbcxDmez/ujIvFmPMFxd4w3Yh4kdNGuPpkkFFDGBJ3KNnaY078Y7WoOcZnMOZzPRM+c1WsZ3E9ruFSk8sROiR6khn9BkOj04PW3f73asroloDqOBdiKYfjqNHgI8FHEkB6enHss93jeyrLGL6q5pVf7ptPsvMHxw//7B6ekHX3zRf/KJR1+aemre+cRDTBxF2N7OJTjV9mqz3m4o2cPZbPWPfjqdnJz0R0eaydwQjwmupv2QEPI+T+wacONoJ9PpyhgczmaHs9nk88/7jz5aqdZQsmQjZknxHt9Oq1/iimTt0jFfXr579mz555+Tk5PJycnk009d9Xr7gmjebwkmv8Tev9wtRDwk20UXtRNOnYg1eIcgYTxxNTmVFIjtBbFqLTwJiSE2Ag9FTOBpvY+dqJ6a0ivvnxtZW+3cIFhecg3DcypS7GPnrbbCaH+4tzPEfMLnUVfECtoJAg9FTOCxtBPS+sGafOIMx5NC9q0CUPXkzOl4LKwKrhkOI0MhFdoJAk/qJ3YZCMwI23kuWeElYo91daQLLJ8atH9eCWZ7OyvXsUUlsjRbB1aItDuP4bUcg8n46YkJPBQxgad17kRJU5pbjNSLi56KtyyNZViz2apS/068c2nG8JrYada6bWzEsHbEfseS/Uh73WgnCDwUMYGnRZy45R4c2cjwHr3HEP4eW8SJpU1FHW/SpvcnanjNRX35naKHdoLAQxETeLIkAHnvQyH16NnWllnF0aV9DdFsoeA65tRxYqsxhM88VpiPp2LGbCKmlr68BNoJAg9FTOBxz53w3me4op0Md8AxnC6pCZqxuVZuSDGxK1mzZRWHNvSL1Qk0Tjkh5ucOSbvvSUc7QfYAipjAE2knTPxfhpxmp5iox91Z1GbmycMQs9wJ6THeXlB6fIaacZ3Qu5d8eaT+WzM26fWx+pLQThB4KGICj2WcOFWBj8xjc0KTf6LJ/5a6AvPPIkWcuPPJ9/VrpD2u9SWU8Wz9AJTQThB4KGICT2R94rFzNQdL48rVucVOOSFROcpjr0O4ryxr7EyGkS04n+T6lGASA/bOYx6DdoLAQxETeFrXJ25ZZy0KD0/p7VNF/tgqBo+6Z8cNTjO/am+XoQ6xNJdaGlz3rlUXNQuknSDwUMQEnhT1iQ1DMxpvt7FfpW8LicU2zm8WuR2PCUwLTxzy3L/wGLIiys5yzw5Cuo4iJntAllTMMTxiw971E6wIGUOGNYtS3NfYadqRxjWtulbGU803dNnSl4ZmdTY0nZZAO0HgoYgJPCnixGtYPYtvdm5hmxrXlCpKWBGH9siluSH7xG6IeV22ir4gksTHcMq1CId2gsBDERN4kOyEFZoaC+UH5AFoqHVYijhkQlYyAGn80ns8Y4eV+O8MuSIe70sD7QSBhyIm8Lh44gaPi62QPt/3iOlmyNMowft94a2x02D10N8qR8Ijn0Hjfa1qEmf7Fo1BO0HgoYgJPEh2QlofLfPeGR5Y7TkCR2oRR9XHderXJHfZYwwe/bZ8X7QTBB6KmMCT2k5sofoub/jYtkEK8sbXTW7BVnt5ZEhVRRVxFOb5AIj5uyUoY/MiaCcIPBQxgWef7UTLvIhsVVC963WI9jrxtkkuIm65B/IQw7zhDHXcosaQ4b2LoJ0g8FDEBB6vfey8scpttTq+mi0dZb6bW+VVm8S/921i57EuLUO9Cw92jgdl/kA7QeChiAk8FDGBp8+wWpMQDfwlJvBQxAQeipjAQxETeChiAg9FTOChiAk8FDGBhyIm8FDEBB6KmMBDERN4KGICD0VM4KGICTwUMYGHIibwUMQEnn8Bm6fPJiMMJx8AAAAASUVORK5CYII=','/assets/images/qrcode/20181204/662653888144571093.png',-1,'2018-12-04 16:42:50','2018-12-04 16:58:03'),(4,'aWWEiKgqwk2u',1,5,'181204165108429218',1,10,9887998,'https://trade.koudaitong.com/wxpay/confirmQr?qr_id=9887998&kdt_id=42192598','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOwAAADsCAIAAAD4sd1DAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAMQ0lEQVR4nO2dvY4cRRSFe2a9OGAHgYhYyStHNinZBg7nGSwRIxEhOfSLQOiYZ8AmIbDkjMiSIbLW0mYjS1j8LPZOE6xYtcfb03Xr/tQ9s+eLzNBdXd1zdurU7Vu3Zn3fd4QgM2/dAUK0UMQEHoqYwEMRE3goYgIPRUzgoYgJPBQxgYciJvBQxAQeipjAQxETeChiAg9FTOChiAk8FDGBhyIm8FDEBB6KmMBzQ3PybDaz6seQy2V/G+2bLwcca7/w8+q+ldxXRR9EfQvuQwnV3y9/iQk8FDGBhyIm8Kg8cTBjVixV6YwK3+xkMUXte/fBFUsRV4upRJ2RT3nsRqz643Rf3hOvyetKseon7QSBhyIm8Lh44sJhYnIYshpuAtrx9p0QntXqe5eCNLHzmMBp2hS9lCmZ8Bm+fJnszxgQfy0b0E4QeChiAg+SnbjEcBgdNiW1AZPdUA7NY6dLm4WIr2tILWKrp2wYl9UkJ0162S39FF3X434zQztB4KGICTyp7URwnHjSH29pCjFOXHK/EKQW8Ras8gRa5RtM4pGnMWSXZnu0EwQeipjAg2ondjJH1mkOUGKZoP2xi4iD47vSlxTljdThkdjkmjdi9cfTSv20EwQeipjAY2knzD2oVZJA4Snmw6th3YySfobV5dh+WDxIE7vqPFqrfNxWxUSaqyQ5tBMEHoqYwINkJ8ZotRQvQ72IzO2HoRJxq7hgSd6tRzvSfAbp8/HOl7Ai29sQ2gkCD0VM4Gnmia1q/Va0L8oTqLAr1U7AcE2ea3hOWVrAPM6demLnkc9glUfbqk6csg87GXumnSDwUMQEHq89O0yGLWUuRHVTyfNuW63n866DUU1LT5whzCw6XuqnpZNXZYZNWGJQSR8ioZ0g8FDEBB4vO6HxbWFDUkU9ipLPzfe0UxLp45vMGVz27AjOrzVZY+eB994cmutK80Y0udTeMXXaCQIPRUzgSf3auZAMzmGIiS9UBoNN1sNle7BjROQTV8cvI2tBjB1vVe+iZG88DzS1OyqOaQLtBIGHIibwWOZOSIebyZHXqW6DFVLbKgpdeV+3onFpm2GWOnRiF5yDK/K1FfFUV6Re1qm+m8fzMffWtBMEHoqYwBNhJ1rVhdC06ZoDYHgjmnAyShh4EtR84ib7ulnNXJVockiq49+ijgVDO0HgoYgJPC3rE4d5MsN6DmNYjaQaL27l46vj0MpX9OnqTljl+JrXiyg53eqvS5ovIb2uYQwbuh4F7QSBhyIm8GTPJ65e3xY8LFZ7RKd+eteOkOLavssau+oDuhyerOEOKyYxWo86FdJ4/JZzzaGdIPBQxAQed08cvLzeI1btXQuiFSZ5I5ql/FZknNiZ7zM3RmQtiE7xBWtqJw+xyquuwLVOHO0EgYciJvBE2wnv2rolDWb2uNI1eUM85htW7iJvnFharKDCk1XX/CpBWo9s7HTQvAXX9F/lsxVBO0HgoYgJPO51J5Q1gD0oiYN6ePfqvAXvRO2Kh2+Sg5E9n3gMk1ipx7kbx6SqO7bx0KzCxhWXrj7GFdoJAg9FTODJGCeWHl+Sy1vifVNZiBI0ntJwrtI8D6RlnLjJXhutaquZIC0I7XR1q7pvVv2knSDwUMQEHjNPXPG6OLK22s6QtrjHdpwyPC/IGCcOqykGN5OLwSSuPIRr7AiZgCIm8LTc21nTSJN39BX0q9W/jx51Xbd///789m1la9vv2jsPW3pK2HM2SxKIrHUQsPbO6rH8/d13//zwQ9d1e3fvfvzjj3tffaVpbSN3wipe2+o5W0E74Ui/Wr39+eeLf5//9tu7J0/a9mdXoYgd6d+8Gf7n+uSkVU92G8t8Ys0pGfJ3zYe//vXr/vTUts0uTej3Eqt86NT5xJH5piZr9aw4f/58Pfgxnh8dmV+ieS5vBmgnHDl/9mz4n7PDw1Y92W0oYi/61er899+Hn8w++aRVZ3YbpH3ssFifnGz8Em9ydtZ1XXfzZkx/Ngj4UsK+d5f6xFZGXpMXUXKi61N+9+TJ+v3oxLvHj+e3bq1fvVq/eLE+Obn4nd5fLm8+eFAo5bq7lqZ9Vx+jqSuiQRXVtwqSF7avOVca5NfWz1ut/vz667cfBIbni0XXde/N9haLg19+Ub4E6ewSqqTHSPvgIeKMVTF3gHdPn17pJTZ+m4kJKUQcsFas+vgK1i9fnn3/faFeZ4eHs88+K2y5bsn+xumT/8tklKvoUps4cXA+rsflzNd+nf/6698PH35oJIK5VqnSKX6JoelXq/XJyfnz5/3p6UfffCNVcH962r9+3akT3K4zFLGK9cuXf3377fmzZ+s3b/bu3t2/f791j64jXmvsUBirWVE4HF8EgzXTtdnhYfXraKdnDrf2McXezuaLuoDYXy5nBwcx1yqpAeJRB3rsdCtl87VzYzZeTZMKKGICj1c+cWR+8JAmS8Y17C+X0vQJzbONrMfs3c4lLXMnyHyx2Ds+Lj++73urZ2vlj0suwboTO85ssWjdBXgo4pbsHR97LPe4bljaiQwuQvMu3n3UWyy6/wPDe3fu7B0f37h3b/b5564XHYP5xNNI17ppkn5E+xKHPdmhZPeXy4t/zBaL+dHR7OCgVS78GJM5JIa+2dwr87WziktHO18sLozB/nK5v1zOv/xy9umnF6pNKNkdwzIpfkiGX2JNuK20P2dnb3/6qf/jj/nR0fzoaP7FF956dYoYVKdfGv4S16eYJhGxBo9tqtK+zQ6eeDQptyAldM+Osc899oBI5Y+vD9LRz+THgiE2Ag9FTOCJrsU2xMmOTx6f1u9OQv9zJSlCbEn2ukPM/bCKzGhi7c33RqGdIPBQxASelnYiMofVu03S+bzYKsEsTqzc38H1mCEBa8hIMLQTBJ4U0QlEpEOn4UhFNmgZJ/ZGGhv2yEVuVSrOY38Tj2eCXRXTyndKfXnD3AlNaVQPqn/1K/JhXEcYemICD0VM4Im2E2O1z4bHePhXK4+4S9G36pG9IrXS1R+75BMnyW1w9WEe/s8qP6GiP+bPKnLuQTtB4KGICTwt6xMnDzNfiYmH09y403NG/C4uSV13oiQeKepMIdDf6AWRdSG8v45JaCcIPBQxgadlfeKS401CP075rFb5EtmQ3ldJ7L+knTZx4oS47nWnKRajua6mwWzxYw9oJwg8FDGBZ9fsxCXBibzeawFbWZpW+dAivNbYmec5eNRua4VHxlIA1ZUzvaGdIPBQxASelvnE0s/Nh6eAIVvUf2XcXfNsS5DGd61WPU1iJuKKHpivELbqT8kBDYuHp71Wq/WLtBMEHoqYwNOy7oSHVyspXVXi4aRDtkfO7q7mZpgTMbETCUuaZ6z5Rq1iz4aetToP22OdnxPMJyZkE4qYwJMld8I8TmyY6yxtxzuPwrUPAev/cuUTa+okBFNdz7gwkh9Zt8Ekjr5Ls0PaCQIPRUzg8fLErrXMKvyuJo6rWTcmJSwveZdIXZ84oOZaZExXQ/XSOu+6eNLjPeZOtBMEHoqYwJNizw7lEOMd2sywzsw77yLDPVbTLHfCqkEn35yh3oJVHyK9exNoJwg8FDGBJ0vuRAmRo16GEda7Dxnu0QSXPTuC2/H2jlceU9LOGJqaaIVtemDSB4+3LbQTBB6KmMCTIk68Qav3+9KYsVVZJzhvWhHXd3UaqSd2ym9dkx985SlwaqsD7n5pJwg8FDGBJ7WdsKr54FQfI5IMfUiLpYgjNyd0zU+1at+qHpxVPWaPeh3SUzz+GmknCDwUMYHHxRNrQmDBfag+3Xu9XcNFex71NFw9feqJXYmHM/xLaBUfNdnrLuHML6xvtBMEHoqYwJPaTmxBU0vY6roZ2sxcwzisD6giliKKv0rrr5W0OXaJ4JwNkzobQ6zqKGugnSDwUMQEnutiJy4pjO9G1l+LbL9VrNe8/vQQVBGb710XWfdt8sPt7Tfps/TcyD3/aCcIPBQxgQfVTkhrCVvVd7Pyhd6ppK1oEp92EbHHN+G9b7CmvlsJVjUxNMdonqHVnn8e0E4QeChiAo+lncjwvn4M1zil9KIVp5j0U9mftH4dcmInNYjKOKV5rbexD4PrB5uv52s1SaWdIPBQxAQeipjAM0vr1gkphL/EBB6KmMBDERN4KGICD0VM4KGICTwUMYGHIibwUMQEHoqYwEMRE3goYgIPRUzgoYgJPBQxgYciJvBQxAQeipjA8x8PLb6YIJvvdwAAAABJRU5ErkJggg==','/assets/images/qrcode/20181204/143273739888366353.png',-1,'2018-12-04 16:51:09','2018-12-04 17:07:02'),(5,'ERh4fNd22WhU',1,6,'181204165933160788',2,1,9888129,'https://trade.koudaitong.com/wxpay/confirmQr?qr_id=9888129&kdt_id=42192598','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOwAAADsCAIAAAD4sd1DAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAL40lEQVR4nO2du44cRRSGe2ZZHLCDQESsxIoIk5JtQDjPYIkYyZElQl4EQmKeAUxCgOSMyBIQWYu02cgSFpfF3hmCRVazTHvqck7V+We+L/Klp7q6+5+ev06dOjXbbDYDgDLz3h0AqAURgzyIGORBxCAPIgZ5EDHIg4hBHkQM8iBikAcRgzyIGORBxCAPIgZ5EDHIg4hBHkQM8iBikAcRgzyIGOR5rebDs9nMqh9jXi77u9X+1L8XHzMm8Vpq+pbbh6zlj4n98WjTiuLlnryJQR5EDPIgYpCnyhOL4mTpzBn3M9ePTh2mcu1ZWIq42JhX3tmt553qTO6Az+Tg4o9I0Ou5vwQ7AfIgYpDHxRPXxEo9sPrZqoyb1nRDwsv2eu6SAzvDu+DxRaqZTNnaTu6EheEEhwTYCZAHEYM8SnYiN25qYhU6GlmrWO/U8XsT8gst4vFdNvRqvR5eVtJP4+SbKSSEjp0AeRAxyBPaTjiR4q1TfkZzPWu0OPHW+6DIIYpYgleMB1wHrIpqxk6APIgY5AltJ15hBL0jTd1nXw2vPSU8J+2PXUTsdBdMFj8WHG/en4L+e8SJzdvspX7sBMiDiEEeSzsRzUfm/qybY9ifLvc2sf/dn3vogV1jwuYtBM+v6A52AuRBxCDPPtiJljkMHnjnDXuftztVIg4YFTcp7GdycMHxg52vdX000Z47dgLkQcQgT4i6E8Hjkbl5BaHyhg0bTGnKpPZzLvswsFOn2AcXrEG0KlQeCuwEyIOIQR4zOxHkp6cmVtqr3FOzPjegS9+8PHHWoG3qalPWmTXwdsXhYavz1rST2Pmdz8WqDx4vO+wEyIOIQZ7W+9hlxRor82sPNpdgTEEMPprP3on7nh2GfijLZ0eIgxZ4+qz1drkfTOxb1scjfMOxEyAPIgZ5euZOWDXrnXebi4m/LDD9VnkdHlucuPrs1vnExfm7jWOu5sdHKIpcOU4IO+DDToA8iBjkiRgnHhP2JyyRln49d08Tq/N2xz13Yox3DkCDHIks7yutjDJc1zhOgZ0AeRAxyONlJ6xihDvb6ZjXe2iEza9wyZ2omYsfY9XO1AEtfdswfX9aFj7sHv/2UD92AuRBxCBPlPrEuXP6LdfDNfPKHlt9VZKSr1JsI62ut2mcuKAqindOgutgMWXtoFX7Edbz9QI7AfIgYpCnRZx4Co/tXWtyBsw9qHcIr0HuijkeHQgRJ07xdi29b4QRVQNqLjPULcJOgDyIGOQJUdq1sr6E97m8l+6o1F3e2Ugv3Pd2rqmr0LIGWYOHUfxlqIk3W9WXyD2efGKADBAxyNPaE7ese5DSoEeNBat2TPa/cMobybUBrm4tyj52NXXWPGKWoeKgTnjXzss6bw3YCZAHEYM8retO5Da19znEHfvQq06F+Wx/z8mOnT7YO4+iV90xp5kF7xh8r8/uBDsB8iBikCdE7sQtdv7iVIbYIvhdD2pyIaLFy7NwjxPnZsd7xyYr9/uIQJa/rKkh7VHbjroTAFtAxCCP197OHpVYrfbsUCfreiPcHO9QZuuBXXGMtmBBaDNPFgTzS/Pek8UK7ATIg4hBnoj5xL064JLSuVr9/dVXwzAc37s3f/998/Y98Kiz5srM6slVxl9za/RaeeupNq1uy58PHvz15ZfDMBzdvfvG118fffSRSbPpVNZCdr3PVmAnHNmsVs+/++7mz9c///zi4cO+/dlXELEjm2fPxn9dX1z06sl+45VPnDuP72G5uu8xsXn6dHN5adtmZe25lDYT/yvrmJTjJfOJPQhVZ/f68eP16GU8Pzvr2Jl0zHMnvJ8FdsKR60ePxn+dnZ726sl+g4i92KxW17/8Mv6X2Ztv9urMfrNvdiIO64uLW2/i21xdDcMw3LnTpj+3aFn/zpue9YmLY5YSvHj4cP3f6MSLb7+dv/fe+tdf1z/9tL64uHlPHy+Xdz77LF3KKXXZnOrfFe+3V9m3nVRF9RNHylabENasds56SPWTHZvV6vdPPnn+v8DwfLEYhuE/o73F4uT7720nQWoK0HhMSOUekwt2woUXP/yw1UvcejeDCS32sTNfM1fwFmlZA2795MnVF18k6nV2ejp7++3Elst66F3brmBnt63HFL+Vq6ITmxFT/1XTfiVd+nD9449/3L//fyMRkK2P7xXP1Py8Vg1iJ2rZrFbri4vrx483l5evf/rpn59/nqXgzeXl5unTQSTBLSaIuIr1kyd/3L9//ejR+tmzo7t3j+/d692jQ0RJxAHjlzfB4Jrh2uz0tNd0dPfcEitCiNhqLVdKDHWMRzJNLsfL5ezkJOsjxSHLMfu0HwrTzp25NTUNBSBikKdFPnHNMbmflStLdbxc5qZP1NTfSHFWNXHfFMwfR4i9nQ+W+WJxdH6efvxms7G6t6/IZ5ADO9GZ2WLRuwvyIOKeHJ2fqyz3iEyL3ImWRKjRO8VNCttNYPjogw+Ozs9f+/jj2TvvuJ50CvKJ82hWu6Amj9n8yY0le7xc3vxhtljMz85mJydWufDFOb5W502JVXuPFENMdujy0tHOF4sbY3C8XB4vl/MPP5y99daNag0lC1uxTIqfotebOOttUTj7dXX1/JtvNr/9Nj87m5+dzd9911uvDdJWU/CYNSyWYhQR52JiJxrXZTMhuGE1t3kpNN3b2dsbea/lOkC8Y/8mz4UQG8iDiEGeFns7mwwCyk5dfHxMhK6iZVdDhNhSvGyDm6KY+2GVQ7yzncrxhuuYBDsB8iBikKeFncitOwHpRMjxLc5XsRojueQTj/GIAU+RWKJqZ7PBg8res24mtLyH2AmQJ0R0IjLeU6aGfThYoucTb/VbTvHmmp/XrPVtlTdKWtMenTfLnbCKQY6x8nyV9MrZTcFjHOLxsth5rhrwxCAPIgZ5mg7sek0pG3rQ4NG3LKzqSY/pUveD6IQ9O7+cBTHvmi9P1iKAljkqVmAnQB5EDPL0zJ2QzgnuVbehwGa0vG9dnlEUT+wai82tO1ZQp0wxFzmFrFzhXgtvsRMgDyIGeVqssatpysTzGZpvk0sOaDlq7qFVLeoQ+cQpRKhjUFwuw/VJJDZVc4ENJpu6jA2wEyAPIgZ5ooTYzEn0cB45vlaOwqqfe1/fwyuf2KpMmxWh/F+QOhtTFOcTEycGKAQRgzxenjg37lsTJ67pT81nW9bTCJX/4FTsQiZOXIzhOjyrfAArPHKF9yl5fyfYCZAHEYM8UXIncs9lXmtiXzHMA+lSry2FKJ7Y3IPu097Fg9G6vYL2TXKFvUft2AmQBxGDPFHshNU6vNwPetePyz0+N5IYqmRH5T3vv49d8Lpdxd6uV26uYX5Fl4ImLcFOgDyIGOSJkjuR26ZHNVjvSFAWTnkX3jsTd6HbwC5XGSkKc6opkYVVzeaU41vWdU4Z8xT0h/rEAMOAiGEPCJE7URNCCmLmvPMQnG616zHNaOGJm+2dUdNgbpy7QW6G9351XXKmPc6FnQB5EDHIEyV3IosGBnFnbLXBT3CovIjImOVORGhnqPNe5h50Cu8CKN4eOvG8zfbNxk6APIgY5AkRJ76FR+0wj5yK3A+a/JIWdMb8MSVeV+64Yj/rTkxdVZD1c6713aza6VUfrSXYCZAHEYM8oe1EY8LW4nU6URcn5nFSSxEXe6yOuQe5eQUe+3e4hts9co4bX9dOsBMgDyIGeVw8cc1S8sR2rPY0DhVXrmzEao8Pwy6Z92Er8gM7j7rFQpkxin02BzsB8iBikEfeTow55J/UQ0ZJxM3quwVMKrCqT2y+x4d37nUK2AmQBxGDPEp2wnXfh9xp5yBY5XvsdCkN8jf2M584F6sZECdMvgAFudTR9uQz7w92AuRBxCCPqp3I9XBWlWTD7uUWhC7X6CJijwRZj70wDM/lUWuihp3x75q9S3KvxVvN2AmQBxGDPJZ2Qjp1obLzHnvXWbWfi3leMvnE/xKt1sQY+vOSLgNW7ATIg4hBHkQM8sz2NeoOhwNvYpAHEYM8iBjkQcQgDyIGeRAxyIOIQR5EDPIgYpAHEYM8iBjkQcQgDyIGeRAxyIOIQR5EDPIgYpAHEYM8/wDQtk7U7bNfEAAAAABJRU5ErkJggg==','/assets/images/qrcode/20181204/346994704119560527.png',1,'2018-12-04 16:59:33','2018-12-04 16:59:52'),(6,'zGr7ssbYJTDj',7,7,'181204222324547987',1,300,9893500,'https://trade.koudaitong.com/wxpay/confirmQr?qr_id=9893500&kdt_id=42192598','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOwAAADsCAIAAAD4sd1DAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAMH0lEQVR4nO2dP28cVRTFZ9aYFHgRiApLsagILZ0Lyv0MkaiRUiGlzBeBMjWfAUJDgZSOKhJQRUZyt4pExB+TeIdikTVsdnbffffPu2d9flViv7nzZvZ458yd++70wzB0hCAzaz0BQrRQxAQeipjAQxETeChiAg9FTOChiAk8FDGBhyIm8FDEBB6KmMBDERN4KGICD0VM4KGICTwUMYGHIibwUMQEHoqYwPOWZuO+763mMeZm2d9G/KmfV48ZU3gsoiWJyjlo9rX3HBrGtKJ6uSe/iQk8FDGBhyIm8Kg8cTBWVswkToBfHIeSxp8a5mRn22Ip4mpjrjyzHv1fUGJmoNXnfgPtBIGHIibwuHhij5xrBnYcV8khT40pOQ8QXrbV5450Y6e5eTJJ/lfMx3XOAQ84IKCdIPBQxAQeJDvhmvsMrhMoQbpr6fmBuyeZIrWIx2dZ4yn3/tAWj/22EhyE0GknCDwUMYEntZ1QUuJANJdLK4/eKk+8tTYDkUMWsYgMn+LUHCIL9jOcBym0EwQeipjAk9pOROZok+SDNfnpvQ6hsPYDzlG4iNjpLJgscjSkulbBsI5Cg3nMVuqnnSDwUMQEHks7EWYrK+ocrHyniApLk2ptXOH8m1dvpr6xUyIVq6ZpiwbzuuHmqgqGdoLAQxETeJDshJVfTOU7d+zX6ri899sclYgbZsVFOdoddckiHyk93orzUz2fgLx4TPAKaCcIPBQxgSdF3wnDfOrUAKu6Ye/aX03/CvPJVIQK6/08BunGzpW0mXxbvHtlNIF2gsBDERN4zOxEkkuPNPdZXVOR5Hiz0eS0eHni6jxuRUyr8XvjOOH6oh3puZ36odU59FA57QSBhyIm8Hi9x06Ty7S6fN+GWgKrfDnX2P1HqzVb0gR7ZB7Uoy/y3n1JBzut+Qv7Y6CdIPBQxASeZo+dDYtlvetuXTE8LuXuzPcb5rOz1BO3ysWGjTfMhVvVHFfvNxu0EwQeipjA45UntgqV9hJWSKRf1/TWSHWfIMW9dqJkgNX6toAaCZH3hVZGHdX3EhpoJwg8FDGBJzRPrFxLp1m/VcItvPqLSFtf4VI7YbWh1bvrpgZE+rZu2i969DOWzqF6fEAvjr3QThB4KGICj1d/YmnP4Or40g0raN53uSHmaxN3BIfpO9Hck5Vs7l0PbW6yu9xr4LyhnSDwUMQEnmg7YX61Urb8d819eqfwKk5mc7fgMQH3PLG0h24G75vhjmpMhvcCGm5rDu0EgYciJvC4e2Lloq5IDyeqCHXqf1wywKMvR6QvN6dZnrhkjOYEpTJta8zXsYlO5u79msynUzwH0EA7QeChiAk8GfPE3rlkj1CRvRo03l0zn63xlXFMSNd3QpNLBtqvCKd1e949iUX71UA7QeChiAk82ftOSHOZHj2Jm2frnC7rrfpUmD/tb/keu+p3VbTqretRBywav/tgvXPwrbbdC+0EgYciJvBkfC2utJbAPD4oGh/vkecOwz1PbNhDd+/mVv1306p844Rb9bCb2sSjtx37ThCyBYqYwOP1bufInO7tAXFR3e45mLiLjH0nSuoWqv3WAfcPNrebGj8dCe0EgYciJvBkrCe2Cti85qHrumG5/Ofx467rju/fn330UevpFOHRZ82V3mPVYSevx5X26DVZr7YjptVp+evLL//++uuu647u3Xvnm2+OPv1UE209YU0zxbDzHPnlQjvhyLBcvvr++/W/r3/55fWTJ23nc6hQxI4ML1+O/7u6uGg1k8PGq564VR3w3jlEerXhxYvh8tI8rPlxKft+WH12kPXEVqRaDzfm+tmz1ejLeHZ21nAy5ZjXTnh/FrQTjlw/fTr+b3962momhw1F7MWwXF7/+uv4J/2777aazGFzCHYi1Xq4G1YXFxvfxJtcXXVd1925EzOfDZL0vzPBpT+xVR+ugF4QfqJ//eTJ6v/ZidfffTe7e3f122+rn39eXVysv6ePF4s7Dx8WSnnHbKV9oKc2N8y7W81tL6qsfmFivLqTZIWITeagf9gxLJd/fP75qzcSw7P5vOu6/93tzecnP/ygfAiygeF52xvHar8aDsFOJOT1jz9u9RIb383EBK/32JX8fGpA9WWrYg4e/m/1/PnVV18V6rU/Pe3ff78wct1svetVND3jTO5nVNmJYcTUrzTxpdNoOIcbrn/66c8HD940EgnZ+vHt+EzN92sVkHZCy7Bcri4urp89Gy4v3/7ii78ePRIpeLi8HF686EAK3HJCEatYPX/+54MH10+frl6+PLp37/j+/dYzuo0giThh/nKdDNbcrvWnp60eR+fMr1eQQsRWa7mm4hTeeTQpEjpeLPqTE9Em1SnLMZpjLNwRayduCxuPpkkFFDGBJ6KeWDNGuq30iV1zjhcLafmEJudd4qw0ed8SzD+ClrUT2eK/uSNvZvP50fl5+fhhGKyOfUc9Axy0E43p5/PWU4CHIm7J0fk5ynKPzETUTkSi8YveedN1Cds6MXz08cdH5+dvffZZ/8EH5jsqgfXE/1Hoq8x7FyjzvjFr8saSPV4s1v/o5/PZ2Vl/cmJVC68pljLZr6ZHntXcUjzswOXG0c7m87UxOF4sjheL2Sef9O+9t1atoWTJVrw6AI2x+iauLsp2LNa+unr17bfD77/Pzs5mZ2ezDz/01mtAR58SPJ4aVkvRcmXHFK1Sb5qccdpaguSGVWPVqs+5l51o4o2ktRNkL2FfQBqYYiPwUMQEHi87UdIvLOCe8sAAOtLCqZrk5iPyxJo4kYU7aYuEdmBVQ7w3TslnVLh5yXxE0E4QeChiAo9XPbFoWJLLd5JpiMhQ49t8rZ57njgyv1ixL2gfnLl/cLVRroB2gsDDAqDtBCwGLgfoKtGEiDxxhjiR8aXr/6ziQ5CuK6a0rlcZR4q5by4hWGEe+Vfvh1Pm0BMTeChiAk9EnnhqfFh6y9CDxixtisGqn/QY6flpXzuxAw//FOnJNH9gJnUIhn5UtAgA8Q+SdoLAQxETeELriXeMkcYc0yT1U9FsrmSeUj9qEtOQJm4kSy+2DI0ATXynZsOEflRUAtFq4S3tBIGHIibwpHiPndO21Xj3KUv4OFeTG7b6jPLmiTWNS5zqHKQnq1UOVdS7o2RMwP1Gk3NFO0HgoYgJPBnriT1859SvMtT4ltwPeFusKaxy+a6E9icuCRXcxbFJzCR9Nqaort9gnpiQSihiAk+WhaKZS4o1OWzvOXgQ1ifEKl/erJ5Y2tvLcB2eVT2AFR61whkeoIRBO0HgoYgJPBHvdpZe8rx7GzfvHRaJYR1I2n5tKW7sPGpqk9TphuW5lcpwfUmP92oG2gkCD0VM4GlpJ1xrha16JyuRHqM0k5hh/tLB5u7Cq3Zib663op44rPdCyU5L5qZRmGF9xSE1fNkK7QSBhyIm8ETXE3vndz3qE7K1dtXkd5266Lal2Y2dVY5Qmg/Olj/2iGOVk94R06q+xeQ80E4QeChiAk9of+LCOGnrGZLUIWgCWuXmU3noCE/s6v+mBij9cbaaYw2p+tx57It2gsBDERN4UpRiStF46Iqa5sJQcKDP/waX99i1imM1B4886xgP9XjMX9l3orqXnBTaCQIPRUzgSZEn3sDjiiPqd+a008jjko7R7FS0VrIizl5S39hNHZXTejLp+Mj+blZz3joGHdoJAg9FTOBJbSdKMLyUN69/CKbJ/D126vIeOyneN4jBjamlQazyqd497PbGrBumh3aCwEMRE3hcPLFmKXlhnJJLVat+wCbuqCJISQ+74CmZz2Er8Dd2G4g+vANYNYlS0+wK7QSBhyIm8ByanRCBsraP7AZJxGEi875rrMCqP7F5nzvv2usSaCcIPBQxgQfJTlj1FBPVFifxzVb9iaVxvFN4JvXcSCKWIirEjuy9YBXHsLbYiib9OmgnCDwUMYEH1U60ehdG2ne5JaHJMbqIOLj3sPe74lzf5Sadm2a89HxWbFse0BDaCQIPRUzg6a1eomGIawv/hCWLmV/RZbLEy6q+fAqYGzsrf6ysIc4mOIj5eEM7QeChiAk8FDGBR3VjR0gG+E1M4KGICTwUMYGHIibwUMQEHoqYwEMRE3goYgIPRUzgoYgJPBQxgYciJvBQxAQeipjAQxETeChiAg9FTOChiAk8/wLLv8zRav+04gAAAABJRU5ErkJggg==','/assets/images/qrcode/20181204/486733367664399221.png',-1,'2018-12-04 22:23:25','2018-12-04 22:39:02');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_callback`
--

DROP TABLE IF EXISTS `payment_callback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_callback` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `yz_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kdt_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kdt_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mode` tinyint(4) DEFAULT NULL,
  `msg` text COLLATE utf8mb4_unicode_ci,
  `sendCount` int(11) DEFAULT NULL,
  `sign` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test` tinyint(4) DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='有赞云回调日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_callback`
--

LOCK TABLES `payment_callback` WRITE;
/*!40000 ALTER TABLE `payment_callback` DISABLE KEYS */;
INSERT INTO `payment_callback` VALUES (1,'84770c5438e0086a6e','E20181204165944013600009','42192598','jkfuns',1,'{\"order_promotion\":{\"adjust_fee\":\"0.00\"},\"refund_order\":[],\"full_order_info\":{\"address_info\":{\"self_fetch_info\":\"\",\"delivery_address\":\"\",\"delivery_postal_code\":\"\",\"receiver_name\":\"\",\"delivery_province\":\"\",\"delivery_city\":\"\",\"delivery_district\":\"\",\"address_extra\":\"{}\",\"receiver_tel\":\"\"},\"remark_info\":{\"buyer_message\":\"\"},\"pay_info\":{\"outer_transactions\":[],\"post_fee\":\"0.00\",\"total_fee\":\"0.01\",\"payment\":\"0.01\",\"transaction\":[]},\"buyer_info\":{\"outer_user_id\":\"\",\"fans_type\":736,\"buyer_id\":1124729992,\"fans_id\":6909182240,\"fans_nickname\":\"alipay_2088202839572437\"},\"orders\":[{\"outer_sku_id\":\"\",\"sku_unique_code\":\"\",\"goods_url\":\"https://h5.youzan.com/v2/showcase/goods?alias=null\",\"item_id\":2147483647,\"outer_item_id\":\"null\",\"discount_price\":\"0.01\",\"item_type\":30,\"num\":1,\"sku_id\":0,\"sku_properties_name\":\"\",\"pic_path\":\"https://img.yzcdn.cn/public_files/2016/12/29/33e6c838cefa614c5121c63c80f860e9.png\",\"oid\":\"1486658468080258979\",\"title\":\"10M\",\"buyer_messages\":\"\",\"is_present\":false,\"pre_sale_type\":\"null\",\"points_price\":\"0\",\"price\":\"0.01\",\"total_fee\":\"0.01\",\"alias\":\"null\",\"payment\":\"0.01\",\"is_pre_sale\":\"null\"}],\"source_info\":{\"is_offline_order\":false,\"book_key\":\"null\",\"biz_source\":\"null\",\"source\":{\"platform\":\"alipay\",\"wx_entrance\":\"direct_buy\"}},\"order_info\":{\"consign_time\":\"\",\"order_extra\":{\"is_from_cart\":\"false\",\"is_member\":\"false\"},\"created\":\"2018-12-04 16:59:44\",\"status_str\":\"待支付\",\"expired_time\":\"2018-12-04 17:29:44\",\"success_time\":\"\",\"type\":6,\"tid\":\"E20181204165944013600009\",\"confirm_time\":\"\",\"pay_time\":\"\",\"update_time\":\"2018-12-04 16:59:44\",\"pay_type_str\":\"\",\"is_retail_order\":false,\"pay_type\":0,\"team_type\":1,\"refund_state\":0,\"close_type\":0,\"status\":\"WAIT_BUYER_PAY\",\"express_type\":9,\"order_tags\":{\"is_secured_transactions\":true}}}}',0,'4ca5694d866c9555e30fd4140a2e8661','WAIT_BUYER_PAY',0,'trade_TradeCreate','1543913984','2018-12-04 16:59:45','2018-12-04 16:59:45'),(2,'84770c5438e0086a6e','E20181204165944013600009','42192598','jkfuns',1,'{\"order_promotion\":{\"adjust_fee\":\"0.00\"},\"qr_info\":{\"qr_id\":9888129,\"qr_pay_id\":25455648,\"qr_name\":\"10M\"},\"refund_order\":[],\"full_order_info\":{\"address_info\":{\"self_fetch_info\":\"\",\"delivery_address\":\"\",\"delivery_postal_code\":\"\",\"receiver_name\":\"\",\"delivery_province\":\"\",\"delivery_city\":\"\",\"delivery_district\":\"\",\"address_extra\":\"{}\",\"receiver_tel\":\"\"},\"remark_info\":{\"buyer_message\":\"\"},\"pay_info\":{\"outer_transactions\":[\"2018120422001472431009713524\"],\"post_fee\":\"0.00\",\"total_fee\":\"0.01\",\"payment\":\"0.01\",\"transaction\":[\"181204165947000005\"]},\"buyer_info\":{\"outer_user_id\":\"\",\"fans_type\":736,\"buyer_id\":1124729992,\"fans_id\":6909182240,\"fans_nickname\":\"alipay_2088202839572437\"},\"orders\":[{\"outer_sku_id\":\"\",\"sku_unique_code\":\"\",\"goods_url\":\"https://h5.youzan.com/v2/showcase/goods?alias=null\",\"item_id\":2147483647,\"outer_item_id\":\"null\",\"discount_price\":\"0.01\",\"item_type\":30,\"num\":1,\"sku_id\":0,\"sku_properties_name\":\"\",\"pic_path\":\"https://img.yzcdn.cn/public_files/2016/12/29/33e6c838cefa614c5121c63c80f860e9.png\",\"oid\":\"1486658468080258979\",\"title\":\"10M\",\"buyer_messages\":\"\",\"is_present\":false,\"pre_sale_type\":\"null\",\"points_price\":\"0\",\"price\":\"0.01\",\"total_fee\":\"0.01\",\"alias\":\"null\",\"payment\":\"0.01\",\"is_pre_sale\":\"null\"}],\"source_info\":{\"is_offline_order\":false,\"book_key\":\"null\",\"biz_source\":\"null\",\"source\":{\"platform\":\"alipay\",\"wx_entrance\":\"direct_buy\"}},\"order_info\":{\"consign_time\":\"\",\"order_extra\":{\"is_from_cart\":\"false\",\"is_member\":\"false\"},\"created\":\"2018-12-04 16:59:44\",\"status_str\":\"已完成\",\"expired_time\":\"2018-12-04 17:29:44\",\"success_time\":\"2018-12-04 16:59:51\",\"type\":6,\"tid\":\"E20181204165944013600009\",\"confirm_time\":\"\",\"pay_time\":\"2018-12-04 16:59:51\",\"update_time\":\"2018-12-04 16:59:51\",\"pay_type_str\":\"ALIPAY\",\"is_retail_order\":false,\"pay_type\":2,\"team_type\":1,\"refund_state\":0,\"close_type\":0,\"status\":\"TRADE_SUCCESS\",\"express_type\":9,\"order_tags\":{\"is_payed\":true,\"is_secured_transactions\":true}}}}',0,'940fd74610e9e234d0dbc3aa5a16cd0c','TRADE_PAID',0,'trade_TradePaid','1543913991','2018-12-04 16:59:52','2018-12-04 16:59:52'),(3,'84770c5438e0086a6e','E20181204165944013600009','42192598','jkfuns',1,'{\"update_time\":\"2018-12-04 16:59:44\",\"tid\":\"E20181204165944013600009\"}',0,'32b99ede908e5672f64b64395ba2848b','TRADE_SUCCESS',0,'trade_TradeSuccess','1543913991','2018-12-04 16:59:52','2018-12-04 16:59:52');
/*!40000 ALTER TABLE `payment_callback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral_apply`
--

DROP TABLE IF EXISTS `referral_apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `referral_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `before` int(11) NOT NULL DEFAULT '0' COMMENT '操作前可提现金额，单位分',
  `after` int(11) NOT NULL DEFAULT '0' COMMENT '操作后可提现金额，单位分',
  `amount` int(11) NOT NULL DEFAULT '0' COMMENT '本次提现金额，单位分',
  `link_logs` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '关联返利日志ID，例如：1,3,4',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态：-1-驳回、0-待审核、1-审核通过待打款、2-已打款',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='提现申请';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_apply`
--

LOCK TABLES `referral_apply` WRITE;
/*!40000 ALTER TABLE `referral_apply` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_apply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral_log`
--

DROP TABLE IF EXISTS `referral_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `referral_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `ref_user_id` int(11) NOT NULL DEFAULT '0' COMMENT '推广人ID',
  `order_id` int(11) NOT NULL DEFAULT '0' COMMENT '关联订单ID',
  `amount` int(11) NOT NULL DEFAULT '0' COMMENT '消费金额，单位分',
  `ref_amount` int(11) NOT NULL DEFAULT '0' COMMENT '返利金额',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态：0-未提现、1-审核中、2-已提现',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='消费返利日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_log`
--

LOCK TABLES `referral_log` WRITE;
/*!40000 ALTER TABLE `referral_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensitive_words`
--

DROP TABLE IF EXISTS `sensitive_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensitive_words` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `words` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '敏感词',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='敏感词';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensitive_words`
--

LOCK TABLES `sensitive_words` WRITE;
/*!40000 ALTER TABLE `sensitive_words` DISABLE KEYS */;
INSERT INTO `sensitive_words` VALUES (1,'chacuo.com'),(2,'chacuo.net'),(3,'1766258.com'),(4,'3202.com'),(5,'4057.com'),(6,'4059.com'),(7,'a7996.com'),(8,'bccto.me'),(9,'bnuis.com'),(10,'chaichuang.com'),(11,'cr219.com'),(12,'cuirushi.org'),(13,'dawin.com'),(14,'jiaxin8736.com'),(15,'lakqs.com'),(16,'urltc.com'),(17,'027168.com'),(18,'10minutemail.net'),(19,'11163.com'),(20,'1shivom.com'),(21,'auoie.com'),(22,'bareed.ws'),(23,'bit-degree.com'),(24,'cjpeg.com'),(25,'cool.fr.nf'),(26,'courriel.fr.nf'),(27,'disbox.net'),(28,'disbox.org'),(29,'fidelium10.com'),(30,'get365.pw'),(31,'ggr.la'),(32,'grr.la'),(33,'guerrillamail.biz'),(34,'guerrillamail.com'),(35,'guerrillamail.de'),(36,'guerrillamail.net'),(37,'guerrillamail.org'),(38,'guerrillamailblock.com'),(39,'hubii-network.com'),(40,'hurify1.com'),(41,'itoup.com'),(42,'jetable.fr.nf'),(43,'jnpayy.com'),(44,'juyouxi.com'),(45,'mail.bccto.me'),(46,'www.bccto.me'),(47,'mega.zik.dj'),(48,'moakt.co'),(49,'moakt.ws'),(50,'molms.com'),(51,'moncourrier.fr.nf'),(52,'monemail.fr.nf'),(53,'monmail.fr.nf'),(54,'nomail.xl.cx'),(55,'nospam.ze.tc'),(56,'pay-mon.com'),(57,'poly-swarm.com'),(58,'sgmh.online'),(59,'sharklasers.com'),(60,'shiftrpg.com'),(61,'spam4.me'),(62,'speed.1s.fr'),(63,'tmail.ws'),(64,'tmails.net'),(65,'tmpmail.net'),(66,'tmpmail.org'),(67,'travala10.com'),(68,'yopmail.com'),(69,'yopmail.fr'),(70,'yopmail.net'),(71,'yuoia.com'),(72,'zep-hyr.com'),(73,'zippiex.com'),(74,'lrc8.com'),(75,'1otc.com'),(76,'emailna.co'),(77,'mailinator.com'),(78,'nbzmr.com'),(79,'awsoo.com'),(80,'zhcne.com'),(81,'0box.eu'),(82,'contbay.com'),(83,'damnthespam.com'),(84,'kurzepost.de'),(85,'objectmail.com'),(86,'proxymail.eu'),(87,'rcpt.at'),(88,'trash-mail.at'),(89,'trashmail.at'),(90,'trashmail.com'),(91,'trashmail.io'),(92,'trashmail.me'),(93,'trashmail.net'),(94,'wegwerfmail.de'),(95,'wegwerfmail.net'),(96,'wegwerfmail.org'),(97,'nwytg.net'),(98,'despam.it'),(99,'spambox.us'),(100,'spam.la'),(101,'mytrashmail.com'),(102,'mt2014.com'),(103,'mt2015.com'),(104,'thankyou2010.com'),(105,'trash2009.com'),(106,'mt2009.com'),(107,'trashymail.com'),(108,'tempemail.net'),(109,'slopsbox.com'),(110,'mailnesia.com');
/*!40000 ALTER TABLE `sensitive_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ss_config`
--

DROP TABLE IF EXISTS `ss_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ss_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '配置名',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '类型：1-加密方式、2-协议、3-混淆',
  `is_default` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否默认：0-不是、1-是',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序：值越大排越前',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='通用配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ss_config`
--

LOCK TABLES `ss_config` WRITE;
/*!40000 ALTER TABLE `ss_config` DISABLE KEYS */;
INSERT INTO `ss_config` VALUES (1,'none',1,0,0),(2,'rc4',1,0,0),(3,'rc4-md5',1,0,0),(4,'rc4-md5-6',1,0,0),(5,'bf-cfb',1,0,0),(6,'aes-128-cfb',1,1,0),(7,'aes-192-cfb',1,0,0),(8,'aes-256-cfb',1,0,0),(9,'aes-128-ctr',1,0,0),(10,'aes-192-ctr',1,0,0),(11,'aes-256-ctr',1,0,0),(12,'camellia-128-cfb',1,0,0),(13,'camellia-192-cfb',1,0,0),(14,'camellia-256-cfb',1,0,0),(15,'salsa20',1,0,0),(16,'xsalsa20',1,0,0),(17,'chacha20',1,0,0),(18,'xchacha20',1,0,0),(19,'chacha20-ietf',1,0,0),(20,'chacha20-ietf-poly1305',1,0,0),(21,'chacha20-poly1305',1,0,0),(22,'xchacha-ietf-poly1305',1,0,0),(23,'aes-128-gcm',1,0,0),(24,'aes-192-gcm',1,0,0),(25,'aes-256-gcm',1,0,0),(26,'sodium-aes-256-gcm',1,0,0),(27,'origin',2,0,0),(28,'auth_sha1_v4',2,1,0),(29,'auth_aes128_md5',2,0,0),(30,'auth_aes128_sha1',2,0,0),(31,'auth_chain_a',2,0,0),(32,'auth_chain_b',2,0,0),(33,'plain',3,1,0),(34,'http_simple',3,0,0),(35,'http_post',3,0,0),(36,'tls1.2_ticket_auth',3,0,0),(37,'tls1.2_ticket_fastauth',3,0,0),(38,'auth_chain_c',2,0,0),(39,'auth_chain_d',2,0,0),(40,'auth_chain_e',2,0,0),(41,'auth_chain_f',2,0,0);
/*!40000 ALTER TABLE `ss_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ss_group`
--

DROP TABLE IF EXISTS `ss_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ss_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分组名称',
  `level` tinyint(4) NOT NULL DEFAULT '1' COMMENT '分组级别',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点分组';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ss_group`
--

LOCK TABLES `ss_group` WRITE;
/*!40000 ALTER TABLE `ss_group` DISABLE KEYS */;
INSERT INTO `ss_group` VALUES (1,'jp',1,'2018-12-04 17:00:55','2018-12-04 18:02:33'),(2,'VPN',1,'2018-12-04 18:06:39','2018-12-04 18:06:39'),(3,'王者',7,'2018-12-04 19:30:16','2018-12-04 19:30:16');
/*!40000 ALTER TABLE `ss_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ss_group_node`
--

DROP TABLE IF EXISTS `ss_group_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ss_group_node` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL DEFAULT '0' COMMENT '分组ID',
  `node_id` int(11) NOT NULL DEFAULT '0' COMMENT '节点ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='分组节点关系表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ss_group_node`
--

LOCK TABLES `ss_group_node` WRITE;
/*!40000 ALTER TABLE `ss_group_node` DISABLE KEYS */;
INSERT INTO `ss_group_node` VALUES (11,1,2);
/*!40000 ALTER TABLE `ss_group_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ss_node`
--

DROP TABLE IF EXISTS `ss_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ss_node` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '服务类型：1-SS、2-V2ray',
  `name` varchar(128) NOT NULL DEFAULT '' COMMENT '名称',
  `group_id` int(11) NOT NULL DEFAULT '0' COMMENT '所属分组',
  `country_code` char(5) NOT NULL DEFAULT 'un' COMMENT '国家代码',
  `server` varchar(128) DEFAULT '' COMMENT '服务器域名地址',
  `ip` char(15) DEFAULT '' COMMENT '服务器IPV4地址',
  `ipv6` char(128) DEFAULT '' COMMENT '服务器IPV6地址',
  `desc` varchar(255) DEFAULT '' COMMENT '节点简单描述',
  `method` varchar(32) NOT NULL DEFAULT 'aes-192-ctr' COMMENT '加密方式',
  `protocol` varchar(128) NOT NULL DEFAULT 'auth_chain_a' COMMENT '协议',
  `protocol_param` varchar(128) DEFAULT '' COMMENT '协议参数',
  `obfs` varchar(128) NOT NULL DEFAULT 'tls1.2_ticket_auth' COMMENT '混淆',
  `obfs_param` varchar(128) DEFAULT '' COMMENT '混淆参数',
  `traffic_rate` float NOT NULL DEFAULT '1' COMMENT '流量比率',
  `bandwidth` int(11) NOT NULL DEFAULT '100' COMMENT '出口带宽，单位M',
  `traffic` bigint(20) NOT NULL DEFAULT '1000' COMMENT '每月可用流量，单位G',
  `monitor_url` varchar(255) DEFAULT NULL COMMENT '监控地址',
  `is_subscribe` tinyint(4) DEFAULT '1' COMMENT '是否允许用户订阅该节点：0-否、1-是',
  `ssh_port` smallint(6) unsigned NOT NULL DEFAULT '22' COMMENT 'SSH端口',
  `is_tcp_check` tinyint(4) NOT NULL DEFAULT '1' COMMENT '是否开启检测: 0-不开启、1-开启',
  `icmp` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'ICMP检测：-2-内外都不通、-1-内不通外通、0-外不通内通、1-内外都通',
  `tcp` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'TCP检测：-2-内外都不通、-1-内不通外通、0-外不通内通、1-内外都通',
  `udp` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'ICMP检测：-2-内外都不通、-1-内不通外通、0-外不通内通、1-内外都通',
  `compatible` tinyint(4) DEFAULT '0' COMMENT '兼容SS',
  `single` tinyint(4) DEFAULT '0' COMMENT '单端口多用户：0-否、1-是',
  `single_force` tinyint(4) DEFAULT NULL COMMENT '模式：0-兼容模式、1-严格模式',
  `single_port` varchar(50) DEFAULT '' COMMENT '端口号，用,号分隔',
  `single_passwd` varchar(50) DEFAULT '' COMMENT '密码',
  `single_method` varchar(50) DEFAULT '' COMMENT '加密方式',
  `single_protocol` varchar(50) NOT NULL DEFAULT '' COMMENT '协议',
  `single_obfs` varchar(50) NOT NULL DEFAULT '' COMMENT '混淆',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序值，值越大越靠前显示',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态：0-维护、1-正常',
  `v2_alter_id` int(11) NOT NULL DEFAULT '16' COMMENT 'V2ray额外ID',
  `v2_port` int(11) NOT NULL DEFAULT '0' COMMENT 'V2ray端口',
  `v2_net` varchar(16) NOT NULL DEFAULT 'tcp' COMMENT 'V2ray传输协议',
  `v2_type` varchar(32) NOT NULL DEFAULT 'none' COMMENT 'V2ray伪装类型',
  `v2_host` varchar(255) NOT NULL DEFAULT '' COMMENT 'V2ray伪装的域名',
  `v2_path` varchar(255) NOT NULL DEFAULT '' COMMENT 'V2ray WS/H2路径',
  `v2_tls` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'V2ray底层传输安全 0 未开启 1 开启',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_group` (`group_id`),
  KEY `idx_sub` (`is_subscribe`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='节点信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ss_node`
--

LOCK TABLES `ss_node` WRITE;
/*!40000 ALTER TABLE `ss_node` DISABLE KEYS */;
INSERT INTO `ss_node` VALUES (2,1,'VPN',1,'jp',NULL,'167.179.88.119',NULL,'日本','aes-128-cfb','auth_sha1_v4',NULL,'plain',NULL,1,1000,1000,NULL,1,2222,1,1,1,1,1,0,0,'','','','','',1,1,16,10087,'tcp','none','','',0,'2018-12-04 18:36:24','2018-12-04 20:57:08');
/*!40000 ALTER TABLE `ss_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ss_node_info`
--

DROP TABLE IF EXISTS `ss_node_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ss_node_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `node_id` int(11) NOT NULL DEFAULT '0' COMMENT '节点ID',
  `uptime` float NOT NULL COMMENT '更新时间',
  `load` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '负载',
  `log_time` int(11) NOT NULL COMMENT '记录时间',
  PRIMARY KEY (`id`),
  KEY `idx_node_id` (`node_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1137 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点负载信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ss_node_info`
--

LOCK TABLES `ss_node_info` WRITE;
/*!40000 ALTER TABLE `ss_node_info` DISABLE KEYS */;
INSERT INTO `ss_node_info` VALUES (1085,2,63649.8,'0.04 0.01 0.00\n',1543977051),(1086,2,63709.9,'0.01 0.01 0.00\n',1543977111),(1087,2,63769.9,'0.14 0.05 0.01\n',1543977171),(1088,2,63829.9,'0.05 0.04 0.01\n',1543977231),(1089,2,63890,'0.02 0.03 0.00\n',1543977291),(1090,2,63950,'0.00 0.02 0.00\n',1543977351),(1091,2,64010,'0.00 0.01 0.00\n',1543977411),(1092,2,64070.1,'0.00 0.01 0.00\n',1543977471),(1093,2,64130.1,'0.00 0.00 0.00\n',1543977531),(1094,2,64190.1,'0.00 0.00 0.00\n',1543977591),(1095,2,64250.2,'0.00 0.00 0.00\n',1543977651),(1096,2,64310.2,'0.00 0.00 0.00\n',1543977711),(1097,2,64370.2,'0.00 0.00 0.00\n',1543977771),(1098,2,64430.3,'0.00 0.00 0.00\n',1543977831),(1099,2,64490.3,'0.00 0.00 0.00\n',1543977891),(1100,2,64550.3,'0.00 0.00 0.00\n',1543977951),(1101,2,64610.4,'0.04 0.01 0.00\n',1543978011),(1102,2,64670.4,'0.01 0.01 0.00\n',1543978071),(1103,2,64730.4,'0.00 0.00 0.00\n',1543978131),(1104,2,64790.5,'0.11 0.04 0.01\n',1543978191),(1105,2,64850.5,'0.04 0.03 0.01\n',1543978251),(1106,2,64910.6,'0.01 0.02 0.00\n',1543978311),(1107,2,64970.6,'0.00 0.02 0.00\n',1543978372),(1108,2,65030.6,'0.00 0.01 0.00\n',1543978432),(1109,2,65090.6,'0.00 0.01 0.00\n',1543978492),(1110,2,65150.7,'0.05 0.02 0.00\n',1543978552),(1111,2,65210.7,'0.02 0.01 0.00\n',1543978612),(1112,2,65270.7,'0.00 0.01 0.00\n',1543978672),(1113,2,65330.8,'0.00 0.00 0.00\n',1543978732),(1114,2,65390.8,'0.00 0.00 0.00\n',1543978792),(1115,2,65450.8,'0.04 0.01 0.00\n',1543978852),(1116,2,65510.9,'0.01 0.01 0.00\n',1543978912),(1117,2,65570.9,'0.00 0.00 0.00\n',1543978972),(1118,2,65631,'0.00 0.00 0.00\n',1543979032),(1119,2,65691,'0.00 0.00 0.00\n',1543979092),(1120,2,65751,'0.00 0.00 0.00\n',1543979152),(1121,2,65811.1,'0.00 0.00 0.00\n',1543979212),(1122,2,65871.1,'0.04 0.01 0.00\n',1543979272),(1123,2,65931.1,'0.01 0.01 0.00\n',1543979332),(1124,2,65991.1,'0.07 0.02 0.00\n',1543979392),(1125,2,66051.2,'0.30 0.12 0.04\n',1543979452),(1126,2,66111.2,'0.11 0.09 0.03\n',1543979512),(1127,2,66171.3,'0.04 0.07 0.03\n',1543979572),(1128,2,66231.3,'0.01 0.06 0.02\n',1543979632),(1129,2,66291.3,'0.00 0.04 0.02\n',1543979692),(1130,2,66351.4,'0.00 0.03 0.01\n',1543979752),(1131,2,66411.4,'0.00 0.03 0.00\n',1543979812),(1132,2,66471.4,'0.00 0.02 0.00\n',1543979872),(1133,2,66531.5,'0.00 0.01 0.00\n',1543979932),(1134,2,66591.5,'0.00 0.01 0.00\n',1543979992),(1135,2,66651.5,'0.00 0.00 0.00\n',1543980052),(1136,2,66711.6,'0.00 0.00 0.00\n',1543980112);
/*!40000 ALTER TABLE `ss_node_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ss_node_ip`
--

DROP TABLE IF EXISTS `ss_node_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ss_node_ip` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `node_id` int(11) NOT NULL DEFAULT '0' COMMENT '节点ID',
  `port` int(11) NOT NULL DEFAULT '0' COMMENT '端口',
  `type` char(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'tcp' COMMENT '类型：tcp、udp',
  `ip` text COLLATE utf8mb4_unicode_ci COMMENT '连接IP：每个IP用,号隔开',
  `created_at` int(11) NOT NULL DEFAULT '0' COMMENT '上报时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ss_node_ip`
--

LOCK TABLES `ss_node_ip` WRITE;
/*!40000 ALTER TABLE `ss_node_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `ss_node_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ss_node_label`
--

DROP TABLE IF EXISTS `ss_node_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ss_node_label` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `node_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `label_id` int(11) NOT NULL DEFAULT '0' COMMENT '标签ID',
  PRIMARY KEY (`id`),
  KEY `idx` (`node_id`,`label_id`),
  KEY `idx_node_id` (`node_id`),
  KEY `idx_label_id` (`label_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点标签';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ss_node_label`
--

LOCK TABLES `ss_node_label` WRITE;
/*!40000 ALTER TABLE `ss_node_label` DISABLE KEYS */;
INSERT INTO `ss_node_label` VALUES (3,2,1),(4,2,2);
/*!40000 ALTER TABLE `ss_node_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ss_node_online_log`
--

DROP TABLE IF EXISTS `ss_node_online_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ss_node_online_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `node_id` int(11) NOT NULL COMMENT '节点ID',
  `online_user` int(11) NOT NULL COMMENT '在线用户数',
  `log_time` int(11) NOT NULL COMMENT '记录时间',
  PRIMARY KEY (`id`),
  KEY `idx_node_id` (`node_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1137 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点在线信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ss_node_online_log`
--

LOCK TABLES `ss_node_online_log` WRITE;
/*!40000 ALTER TABLE `ss_node_online_log` DISABLE KEYS */;
INSERT INTO `ss_node_online_log` VALUES (1055,2,1,1543975249),(1056,2,1,1543975309),(1057,2,1,1543975369),(1058,2,1,1543975429),(1059,2,1,1543975489),(1060,2,1,1543975549),(1061,2,1,1543975609),(1062,2,1,1543975669),(1063,2,1,1543975729),(1064,2,1,1543975789),(1065,2,1,1543975849),(1066,2,1,1543975909),(1067,2,1,1543975969),(1068,2,1,1543976030),(1069,2,1,1543976090),(1070,2,1,1543976150),(1071,2,1,1543976210),(1072,2,1,1543976270),(1073,2,1,1543976330),(1074,2,1,1543976390),(1075,2,1,1543976450),(1076,2,1,1543976510),(1077,2,1,1543976570),(1078,2,0,1543976630),(1079,2,0,1543976690),(1080,2,0,1543976750),(1081,2,0,1543976810),(1082,2,0,1543976870),(1083,2,0,1543976930),(1084,2,0,1543976991),(1085,2,0,1543977051),(1086,2,0,1543977111),(1087,2,0,1543977171),(1088,2,0,1543977231),(1089,2,0,1543977291),(1090,2,0,1543977351),(1091,2,0,1543977411),(1092,2,0,1543977471),(1093,2,0,1543977531),(1094,2,0,1543977591),(1095,2,0,1543977651),(1096,2,0,1543977711),(1097,2,0,1543977771),(1098,2,0,1543977831),(1099,2,0,1543977891),(1100,2,0,1543977951),(1101,2,0,1543978011),(1102,2,0,1543978071),(1103,2,0,1543978131),(1104,2,0,1543978191),(1105,2,0,1543978251),(1106,2,0,1543978311),(1107,2,0,1543978371),(1108,2,0,1543978432),(1109,2,0,1543978492),(1110,2,0,1543978552),(1111,2,0,1543978612),(1112,2,0,1543978672),(1113,2,0,1543978732),(1114,2,0,1543978792),(1115,2,0,1543978852),(1116,2,0,1543978912),(1117,2,0,1543978972),(1118,2,0,1543979032),(1119,2,0,1543979092),(1120,2,0,1543979152),(1121,2,0,1543979212),(1122,2,0,1543979272),(1123,2,0,1543979332),(1124,2,0,1543979392),(1125,2,0,1543979452),(1126,2,0,1543979512),(1127,2,0,1543979572),(1128,2,0,1543979632),(1129,2,0,1543979692),(1130,2,0,1543979752),(1131,2,0,1543979812),(1132,2,0,1543979872),(1133,2,0,1543979932),(1134,2,0,1543979992),(1135,2,0,1543980052),(1136,2,0,1543980112);
/*!40000 ALTER TABLE `ss_node_online_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ss_node_traffic_daily`
--

DROP TABLE IF EXISTS `ss_node_traffic_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ss_node_traffic_daily` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `node_id` int(11) NOT NULL DEFAULT '0' COMMENT '节点ID',
  `u` bigint(20) NOT NULL DEFAULT '0' COMMENT '上传流量',
  `d` bigint(20) NOT NULL DEFAULT '0' COMMENT '下载流量',
  `total` bigint(20) NOT NULL DEFAULT '0' COMMENT '总流量',
  `traffic` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '总流量（带单位）',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_node_id` (`node_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点每日流量统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ss_node_traffic_daily`
--

LOCK TABLES `ss_node_traffic_daily` WRITE;
/*!40000 ALTER TABLE `ss_node_traffic_daily` DISABLE KEYS */;
INSERT INTO `ss_node_traffic_daily` VALUES (1,2,0,0,0,'0B','2018-12-04 23:55:02','2018-12-04 23:55:02');
/*!40000 ALTER TABLE `ss_node_traffic_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ss_node_traffic_hourly`
--

DROP TABLE IF EXISTS `ss_node_traffic_hourly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ss_node_traffic_hourly` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `node_id` int(11) NOT NULL DEFAULT '0' COMMENT '节点ID',
  `u` bigint(20) NOT NULL DEFAULT '0' COMMENT '上传流量',
  `d` bigint(20) NOT NULL DEFAULT '0' COMMENT '下载流量',
  `total` bigint(20) NOT NULL DEFAULT '0' COMMENT '总流量',
  `traffic` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '总流量（带单位）',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_node_id` (`node_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点每小时流量统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ss_node_traffic_hourly`
--

LOCK TABLES `ss_node_traffic_hourly` WRITE;
/*!40000 ALTER TABLE `ss_node_traffic_hourly` DISABLE KEYS */;
INSERT INTO `ss_node_traffic_hourly` VALUES (3,2,0,0,0,'0B','2018-12-04 19:00:02','2018-12-04 19:00:02'),(4,2,0,0,0,'0B','2018-12-04 20:00:02','2018-12-04 20:00:02'),(5,2,0,0,0,'0B','2018-12-04 21:00:02','2018-12-04 21:00:02'),(6,2,869312,62515477,63384789,'60.45MB','2018-12-04 22:00:03','2018-12-04 22:00:03'),(7,2,429677,63999114,64428791,'61.44MB','2018-12-04 23:00:03','2018-12-04 23:00:03'),(8,2,2120988,228987553,231108541,'220.4MB','2018-12-05 00:00:03','2018-12-05 00:00:03'),(9,2,2070877,26032985,28103862,'26.8MB','2018-12-05 01:00:03','2018-12-05 01:00:03'),(10,2,121748,405078,526826,'514.48KB','2018-12-05 02:00:02','2018-12-05 02:00:02'),(11,2,516908,2988055,3504963,'3.34MB','2018-12-05 03:00:02','2018-12-05 03:00:02'),(12,2,57000,2259018,2316018,'2.21MB','2018-12-05 04:00:02','2018-12-05 04:00:02'),(13,2,7665,17813,25478,'24.88KB','2018-12-05 05:00:02','2018-12-05 05:00:02'),(14,2,10027,22981,33008,'32.23KB','2018-12-05 06:00:02','2018-12-05 06:00:02'),(15,2,0,0,0,'0B','2018-12-05 07:00:02','2018-12-05 07:00:02'),(16,2,0,0,0,'0B','2018-12-05 08:00:02','2018-12-05 08:00:02'),(17,2,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(18,2,148441,2649091,2797532,'2.67MB','2018-12-05 10:00:02','2018-12-05 10:00:02'),(19,2,88035,857417,945452,'923.29KB','2018-12-05 11:00:03','2018-12-05 11:00:03');
/*!40000 ALTER TABLE `ss_node_traffic_hourly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内容',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态：0-待处理、1-已处理未关闭、2-已关闭',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_reply`
--

DROP TABLE IF EXISTS `ticket_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_reply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL DEFAULT '0' COMMENT '工单ID',
  `user_id` int(11) NOT NULL COMMENT '回复人ID',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '回复内容',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工单回复';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_reply`
--

LOCK TABLES `ticket_reply` WRITE;
/*!40000 ALTER TABLE `ticket_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '密码',
  `port` int(11) NOT NULL DEFAULT '0' COMMENT 'SS端口',
  `passwd` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'SS密码',
  `vmess_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'V2ray用户ID',
  `transfer_enable` bigint(20) NOT NULL DEFAULT '1073741824000' COMMENT '可用流量，单位字节，默认1TiB',
  `u` bigint(20) NOT NULL DEFAULT '0' COMMENT '已上传流量，单位字节',
  `d` bigint(20) NOT NULL DEFAULT '0' COMMENT '已下载流量，单位字节',
  `t` int(11) NOT NULL DEFAULT '0' COMMENT '最后使用时间',
  `enable` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'SS状态',
  `method` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'aes-256-cfb' COMMENT '加密方式',
  `protocol` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'origin' COMMENT '协议',
  `protocol_param` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '协议参数',
  `obfs` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'plain' COMMENT '混淆',
  `obfs_param` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '混淆参数',
  `speed_limit_per_con` int(255) NOT NULL DEFAULT '204800' COMMENT '单连接限速，默认200M，单位KB',
  `speed_limit_per_user` int(255) NOT NULL DEFAULT '204800' COMMENT '单用户限速，默认200M，单位KB',
  `gender` tinyint(4) NOT NULL DEFAULT '1' COMMENT '性别：0-女、1-男',
  `wechat` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '微信',
  `qq` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'QQ',
  `usage` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '4' COMMENT '用途：1-手机、2-电脑、3-路由器、4-其他',
  `pay_way` tinyint(4) NOT NULL DEFAULT '0' COMMENT '付费方式：0-免费、1-季付、2-月付、3-半年付、4-年付',
  `balance` int(11) NOT NULL DEFAULT '0' COMMENT '余额，单位分',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `enable_time` date DEFAULT NULL COMMENT '开通日期',
  `expire_time` date NOT NULL DEFAULT '2099-01-01' COMMENT '过期时间',
  `ban_time` int(11) NOT NULL DEFAULT '0' COMMENT '封禁到期时间',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `level` tinyint(4) NOT NULL DEFAULT '1' COMMENT '等级：可定义名称',
  `is_admin` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否管理员：0-否、1-是',
  `reg_ip` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '127.0.0.1' COMMENT '注册IP',
  `last_login` int(11) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `referral_uid` int(11) NOT NULL DEFAULT '0' COMMENT '邀请人',
  `traffic_reset_day` tinyint(4) NOT NULL DEFAULT '0' COMMENT '流量自动重置日，0表示不重置',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态：-1-禁用、0-未激活、1-正常',
  `remember_token` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_search` (`enable`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','$2y$10$1rKLjDFTy9J4dyUrgR85w.tXLYCEwBwSXk.aF5JSBwE1W2JXnt8Qq',2333,'admin888','c6effafd-6046-7a84-376e-b0429751c304',1074826051584,1201093,9780583,1543957479,1,'aes-128-cfb','auth_sha1_v4',NULL,'plain',NULL,204800,204800,1,NULL,NULL,'1',3,0,39,'2017-01-01','2099-01-01',0,'',1,1,'127.0.0.1',1543973714,0,0,1,'JpnFBKXElWVKfH23wd0zREHuaPT23VfPLPHorEW4032qUHb4NIh4F1UPAgWf','2018-12-04 14:20:58','2018-12-05 09:35:14'),(2,'aasd','$2y$10$2m1u.3Nv9d23YEwED/kJQugRKclhh/mpZiKvVpes1J6LP6T4AI0qO',10000,'UGCFzM','102f519c-a7df-1d89-00b4-e7d207366f68',1073741824,0,0,0,1,'aes-128-cfb','auth_sha1_v4',NULL,'plain',NULL,204800,204800,1,NULL,NULL,'4',0,0,0,'2018-12-04','2018-12-11',0,'',1,0,'27.26.156.32',0,0,0,0,'','2018-12-04 16:05:55','2018-12-04 16:09:18'),(3,'599948174@qq.com','$2y$10$1Jpr2/IX8NG0DHbOTahCruKokS8g7IUZQb5EV.xymJrNV18Hb5pwe',10001,'JwSmuT','bf8de9a4-afba-5ddf-59c8-27c70c131c66',1073741824,0,0,0,1,'aes-128-cfb','auth_sha1_v4',NULL,'plain',NULL,204800,204800,1,NULL,NULL,'4',0,0,0,'2018-12-04','2018-12-11',0,'',1,0,'27.26.156.32',0,0,0,1,'rIFFFUY59ggURHevCjFL95GPe9v73GMwXMPTuDDvIdbgzqfOwVctC06sjpnp','2018-12-04 16:09:43','2018-12-04 16:42:24'),(4,'931512501@qq.com','$2y$10$mf/wVk1Qtp0VQRI2/DIcUurTs0z/y7pgD/BizBYBZVYh5nqxm0DVq',10002,'aC2ape','5ecd4fc2-69ff-bc3d-2b64-489ed2e42cdc',1073741824,5589571,383927052,1543975909,1,'aes-128-cfb','auth_sha1_v4',NULL,'plain',NULL,204800,204800,1,NULL,NULL,'4',4,0,88,'2018-12-04','2018-12-11',0,'',1,0,'27.26.156.32',1543917874,0,0,1,'BLeGvtqdcNExutBKXXZ9S6xIodWvbf7YspaTb0qXCBDASt1DDhfspNqf60v2','2018-12-04 16:19:30','2018-12-04 21:04:31'),(5,'lilili','$2y$10$B1uz0sPrt0onVHkXWvk3kuykS0p.1dNiClsNCHq1rKzu4pHvIEJ/a',10003,'8gmd29','c45f5b45-fa0e-c557-d127-6a9391a252ad',1073741824000,0,0,0,1,'aes-128-cfb','auth_sha1_v4',NULL,'plain',NULL,204800,204800,1,NULL,NULL,'1,2,4',3,0,83,'2018-12-04','2019-12-04',0,'',7,0,'27.26.7.251',1543924106,0,0,1,'cufWwWhNyT3gfFXt9Lo6BL6hWeD7EHLhmjSYs94o3xpr2P2ga3McHNtAAoY1','2018-12-04 18:28:20','2018-12-04 19:48:26'),(6,'1756704416@QQ.COM','$2y$10$ZGIApfT.2Yzh9aqdGFCtRetWR3ZBdv4XW5Nh8nNnIsS5V53LCIk/S',10004,'USP2tP','96091ef7-14b3-de24-d6d1-a55c5f1a43a6',209715200,1705,170081,1543933525,1,'aes-128-cfb','auth_sha1_v4','','plain','',204800,204800,1,'','','4',0,0,36,'2018-12-04','2019-01-03',0,NULL,1,0,'93.179.100.45',1543931612,0,0,1,'','2018-12-04 21:52:30','2018-12-04 21:53:32'),(7,'314670899@qq.com','$2y$10$i7h10pz8U3GdPT3nkztn..RljsZoN4YmAqkVpFRg.eBg73WqY41vS',10005,'sxS53F','e1c10a37-0c3f-02b2-4cef-1ca3b38f0cea',209715200,0,0,0,1,'aes-128-cfb','auth_sha1_v4','','plain','',204800,204800,1,'','','4',0,0,96,'2018-12-04','2019-01-03',0,NULL,1,0,'61.183.81.138',1543933389,0,0,1,'','2018-12-04 22:22:36','2018-12-04 22:23:09');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_balance_log`
--

DROP TABLE IF EXISTS `user_balance_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_balance_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '账号ID',
  `order_id` int(11) NOT NULL DEFAULT '0' COMMENT '订单ID',
  `before` int(11) NOT NULL DEFAULT '0' COMMENT '发生前余额，单位分',
  `after` int(11) NOT NULL DEFAULT '0' COMMENT '发生后金额，单位分',
  `amount` int(11) NOT NULL DEFAULT '0' COMMENT '发生金额，单位分',
  `desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '操作描述',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户余额变动日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_balance_log`
--

LOCK TABLES `user_balance_log` WRITE;
/*!40000 ALTER TABLE `user_balance_log` DISABLE KEYS */;
INSERT INTO `user_balance_log` VALUES (1,1,1,0,0,0,'购买服务：JP','2018-12-04 15:59:25');
/*!40000 ALTER TABLE `user_balance_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_ban_log`
--

DROP TABLE IF EXISTS `user_ban_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_ban_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `minutes` int(11) NOT NULL DEFAULT '0' COMMENT '封禁账号时长，单位分钟',
  `desc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '操作描述',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态：0-未处理、1-已处理',
  `created_at` datetime DEFAULT NULL COMMENT ' 创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户封禁日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_ban_log`
--

LOCK TABLES `user_ban_log` WRITE;
/*!40000 ALTER TABLE `user_ban_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_ban_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_label`
--

DROP TABLE IF EXISTS `user_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_label` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `label_id` int(11) NOT NULL DEFAULT '0' COMMENT '标签ID',
  PRIMARY KEY (`id`),
  KEY `idx` (`user_id`,`label_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_label_id` (`label_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户标签';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_label`
--

LOCK TABLES `user_label` WRITE;
/*!40000 ALTER TABLE `user_label` DISABLE KEYS */;
INSERT INTO `user_label` VALUES (1,4,1),(2,6,1),(3,6,2),(4,7,1),(5,7,2);
/*!40000 ALTER TABLE `user_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_login_log`
--

DROP TABLE IF EXISTS `user_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_login_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `ip` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `county` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isp` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户登录日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_login_log`
--

LOCK TABLES `user_login_log` WRITE;
/*!40000 ALTER TABLE `user_login_log` DISABLE KEYS */;
INSERT INTO `user_login_log` VALUES (1,1,'27.26.156.32','中国','湖北','孝感市','','电信','中国湖北孝感市电信','2018-12-04 14:36:41','2018-12-04 14:36:41'),(2,1,'27.26.7.251','中国','湖北','襄阳市','','电信','中国湖北襄阳市电信','2018-12-04 14:38:33','2018-12-04 14:38:33'),(3,1,'27.26.156.32','中国','湖北','孝感市','','电信','中国湖北孝感市电信','2018-12-04 16:07:39','2018-12-04 16:07:39'),(4,1,'27.26.156.32','中国','湖北','孝感市','','电信','中国湖北孝感市电信','2018-12-04 16:21:06','2018-12-04 16:21:06'),(5,4,'27.26.156.32','中国','湖北','孝感市','','电信','中国湖北孝感市电信','2018-12-04 16:32:15','2018-12-04 16:32:15'),(6,1,'27.26.156.32','中国','湖北','孝感市','','电信','中国湖北孝感市电信','2018-12-04 16:34:13','2018-12-04 16:34:13'),(7,1,'27.26.156.32','中国','湖北','孝感市','','电信','中国湖北孝感市电信','2018-12-04 16:34:21','2018-12-04 16:34:21'),(8,4,'27.26.156.32','中国','湖北','孝感市','','电信','中国湖北孝感市电信','2018-12-04 16:35:20','2018-12-04 16:35:20'),(9,1,'27.26.156.32','中国','湖北','孝感市','','电信','中国湖北孝感市电信','2018-12-04 16:39:58','2018-12-04 16:39:58'),(10,4,'27.26.7.251','中国','湖北','襄阳市','','电信','中国湖北襄阳市电信','2018-12-04 17:29:22','2018-12-04 17:29:22'),(11,1,'27.26.7.251','中国','湖北','襄阳市','','电信','中国湖北襄阳市电信','2018-12-04 17:30:06','2018-12-04 17:30:06'),(12,4,'27.26.7.251','中国','湖北','襄阳市','','电信','中国湖北襄阳市电信','2018-12-04 18:04:34','2018-12-04 18:04:34'),(13,1,'27.26.7.251','中国','湖北','襄阳市','','电信','中国湖北襄阳市电信','2018-12-04 18:06:16','2018-12-04 18:06:16'),(14,5,'27.26.7.251','中国','湖北','襄阳市','','电信','中国湖北襄阳市电信','2018-12-04 18:29:14','2018-12-04 18:29:14'),(15,1,'27.26.7.251','中国','湖北','襄阳市','','电信','中国湖北襄阳市电信','2018-12-04 18:32:51','2018-12-04 18:32:51'),(16,1,'113.129.169.183','中国','山东','济南市','','电信','中国山东济南市电信','2018-12-04 19:17:55','2018-12-04 19:17:55'),(17,5,'27.26.7.251','中国','湖北','襄阳市','','电信','中国湖北襄阳市电信','2018-12-04 19:48:26','2018-12-04 19:48:26'),(18,1,'27.26.7.251','中国','湖北','襄阳市','','电信','中国湖北襄阳市电信','2018-12-04 19:57:43','2018-12-04 19:57:43'),(19,6,'93.179.100.45','俄罗斯','','','','','俄罗斯','2018-12-04 21:53:32','2018-12-04 21:53:32'),(20,7,'61.183.81.138','中国','湖北','武汉市','','电信','中国湖北武汉市电信','2018-12-04 22:23:09','2018-12-04 22:23:09'),(21,1,'27.26.7.251','中国','湖北','襄阳市','','电信','中国湖北襄阳市电信','2018-12-05 09:35:14','2018-12-05 09:35:14');
/*!40000 ALTER TABLE `user_login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_score_log`
--

DROP TABLE IF EXISTS `user_score_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_score_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '账号ID',
  `before` int(11) NOT NULL DEFAULT '0' COMMENT '发生前积分',
  `after` int(11) NOT NULL DEFAULT '0' COMMENT '发生后积分',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '发生积分',
  `desc` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '描述',
  `created_at` datetime DEFAULT NULL COMMENT '创建日期',
  PRIMARY KEY (`id`),
  KEY `idx` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户积分变动日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_score_log`
--

LOCK TABLES `user_score_log` WRITE;
/*!40000 ALTER TABLE `user_score_log` DISABLE KEYS */;
INSERT INTO `user_score_log` VALUES (1,1,0,39,39,'登录送积分','2018-12-04 14:36:41'),(2,4,0,88,88,'登录送积分','2018-12-04 16:32:15'),(3,5,0,83,83,'登录送积分','2018-12-04 18:29:14'),(4,6,0,36,36,'登录送积分','2018-12-04 21:53:32'),(5,7,0,96,96,'登录送积分','2018-12-04 22:23:09');
/*!40000 ALTER TABLE `user_score_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_subscribe`
--

DROP TABLE IF EXISTS `user_subscribe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_subscribe` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `code` char(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '订阅地址唯一识别码',
  `times` int(11) NOT NULL DEFAULT '0' COMMENT '地址请求次数',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态：0-禁用、1-启用',
  `ban_time` int(11) NOT NULL DEFAULT '0' COMMENT '封禁时间',
  `ban_desc` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '封禁理由',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户订阅';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_subscribe`
--

LOCK TABLES `user_subscribe` WRITE;
/*!40000 ALTER TABLE `user_subscribe` DISABLE KEYS */;
INSERT INTO `user_subscribe` VALUES (1,1,'3yRjB',12,1,0,'','2018-12-04 15:47:54','2018-12-04 19:10:01'),(2,2,'w4AxH',0,1,0,'','2018-12-04 16:07:57','2018-12-04 16:07:57'),(3,3,'eVU3u',0,1,0,'','2018-12-04 16:19:05','2018-12-04 16:19:05'),(4,4,'EkNaB',25,1,0,'','2018-12-04 16:32:15','2018-12-05 09:52:27'),(5,5,'KDw2Q',22,1,0,'','2018-12-04 18:29:14','2018-12-04 20:51:59'),(6,6,'dBT74',2,1,0,'','2018-12-04 21:53:32','2018-12-04 22:15:22'),(7,7,'wqTFq',0,1,0,'','2018-12-04 22:23:10','2018-12-04 22:23:10');
/*!40000 ALTER TABLE `user_subscribe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_subscribe_log`
--

DROP TABLE IF EXISTS `user_subscribe_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_subscribe_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL COMMENT '对应user_subscribe的id',
  `request_ip` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '请求IP',
  `request_time` datetime DEFAULT NULL COMMENT '请求时间',
  `request_header` text COLLATE utf8mb4_unicode_ci COMMENT '请求头部信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户订阅访问日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_subscribe_log`
--

LOCK TABLES `user_subscribe_log` WRITE;
/*!40000 ALTER TABLE `user_subscribe_log` DISABLE KEYS */;
INSERT INTO `user_subscribe_log` VALUES (1,1,'27.26.156.32','2018-12-04 17:09:02','Accept:                    text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\nAccept-Encoding:           gzip, deflate, sdch\r\nAccept-Language:           zh-CN,zh;q=0.8\r\nConnection:                keep-alive\r\nContent-Length:            \r\nContent-Type:              \r\nCookie:                    XSRF-TOKEN=eyJpdiI6IkJCN2c3VHJcL2IzdDAxUVRoa1ZcL0tTdz09IiwidmFsdWUiOiJHV1prXC85M3NiXC9pS3NVTTYrVE53cDNDbnVDcWdjNkdZUFFiMlNMa01KblFPQlN2dzVEMHdESG93TVJ2RmZLVGZqMWVYWDRINVhWUlVvODNaeGozQWZ3PT0iLCJtYWMiOiI0NDFjODFkZGFmMzAzZTNmNWIyMDE3Y2U5MDdlYTU5ZjUwNDIzZWJiYTYwYThlMzFjNzk0ZmJjZTI5OGRhM2QxIn0%3D; ssrpanel_session=eyJpdiI6Imx1dUlLaE1MWktiXC9lSWE4Q3l5RDlBPT0iLCJ2YWx1ZSI6IkJVQms3OU5NcjcyUTNBQ1puNzUwckpWMmZIVnhUT1lyUWh4azFsY1dyU2dnejNzS0ZnYlF3dmpMSm1RRFpaeERjSUU5Y3R2T3BQRjRjTXozRlhrSllnPT0iLCJtYWMiOiIzMTUyN2QyYzQxZTZlNDA2NzVjYWNmY2FmYzY2OWI3ZjQ5MDkwNDNmY2M1ODUzYTI3MzQ1NDk2Y2I0NjhkZTMzIn0%3D; _ga=GA1.2.27318536.1543905011; _gid=GA1.2.1216477844.1543905011\r\nHost:                      ssr.jkfuns.fun\r\nUpgrade-Insecure-Requests: 1\r\nUser-Agent:                Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 SE 2.X MetaSr 1.0\r\n'),(2,1,'27.26.156.32','2018-12-04 17:21:55','Connection:     Keep-Alive\r\nContent-Length: \r\nContent-Type:   \r\nHost:           ssr.jkfuns.fun\r\nUser-Agent:     Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.3319.102 Safari/537.36\r\n'),(3,1,'167.179.88.119','2018-12-04 17:22:53','Connection:     close\r\nContent-Length: \r\nContent-Type:   \r\nHost:           ssr.jkfuns.fun\r\nUser-Agent:     Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.3319.102 Safari/537.36\r\n'),(4,1,'27.26.156.32','2018-12-04 17:23:53','Connection:     Keep-Alive\r\nContent-Length: \r\nContent-Type:   \r\nHost:           ssr.jkfuns.fun\r\nUser-Agent:     Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.3319.102 Safari/537.36\r\n'),(5,1,'27.26.156.32','2018-12-04 17:24:10','Content-Length: \r\nContent-Type:   \r\nHost:           ssr.jkfuns.fun\r\nUser-Agent:     Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.3319.102 Safari/537.36\r\n'),(6,1,'27.26.7.251','2018-12-04 17:55:01','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(7,1,'27.26.7.251','2018-12-04 17:55:44','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(8,1,'27.26.7.251','2018-12-04 17:58:44','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(9,1,'27.26.7.251','2018-12-04 17:59:10','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(10,1,'27.26.7.251','2018-12-04 17:59:49','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(11,4,'27.26.7.251','2018-12-04 18:04:58','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(12,1,'27.26.7.251','2018-12-04 18:05:00','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(13,4,'27.26.7.251','2018-12-04 18:05:00','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(14,4,'27.26.7.251','2018-12-04 18:05:40','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(15,4,'27.26.7.251','2018-12-04 18:05:46','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(16,4,'27.26.7.251','2018-12-04 18:07:27','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(17,4,'27.26.7.251','2018-12-04 18:07:39','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(18,4,'27.26.7.251','2018-12-04 18:07:44','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(19,4,'27.26.7.251','2018-12-04 18:07:45','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(20,4,'27.26.7.251','2018-12-04 18:26:30','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(21,4,'27.26.7.251','2018-12-04 18:26:31','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(22,5,'27.26.7.251','2018-12-04 18:29:58','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(23,5,'27.26.7.251','2018-12-04 18:30:01','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(24,5,'27.26.7.251','2018-12-04 18:49:49','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(25,5,'27.26.7.251','2018-12-04 19:04:37','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(26,5,'27.26.7.251','2018-12-04 19:04:39','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(27,5,'27.26.7.251','2018-12-04 19:04:39','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(28,5,'27.26.7.251','2018-12-04 19:08:43','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(29,5,'27.26.7.251','2018-12-04 19:08:44','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(30,1,'27.26.156.32','2018-12-04 19:10:01','Connection:     Keep-Alive\r\nContent-Length: \r\nContent-Type:   \r\nHost:           ssr.jkfuns.fun\r\nUser-Agent:     Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.3319.102 Safari/537.36\r\n'),(31,5,'27.26.7.251','2018-12-04 19:12:25','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(32,5,'27.26.7.251','2018-12-04 19:12:26','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(33,5,'27.26.7.251','2018-12-04 19:22:59','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(34,5,'27.26.7.251','2018-12-04 19:23:00','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(35,5,'27.26.7.251','2018-12-04 19:32:37','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(36,5,'27.26.7.251','2018-12-04 19:32:39','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(37,5,'27.26.7.251','2018-12-04 19:37:28','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(38,5,'27.26.7.251','2018-12-04 19:49:16','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(39,5,'27.26.7.251','2018-12-04 19:49:17','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(40,5,'27.26.7.251','2018-12-04 19:49:19','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(41,5,'27.26.7.251','2018-12-04 20:08:16','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(42,5,'27.26.7.251','2018-12-04 20:08:17','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(43,5,'27.26.7.251','2018-12-04 20:51:57','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(44,5,'27.26.7.251','2018-12-04 20:51:59','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(45,4,'27.26.7.251','2018-12-04 20:55:47','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(46,4,'27.26.7.251','2018-12-04 20:55:50','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(47,4,'27.26.7.251','2018-12-04 20:55:58','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(48,4,'27.26.7.251','2018-12-04 20:57:17','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(49,4,'27.26.7.251','2018-12-04 20:57:23','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(50,4,'27.26.7.251','2018-12-04 20:57:31','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(51,4,'27.26.7.251','2018-12-04 20:57:44','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(52,4,'27.26.7.251','2018-12-04 21:04:48','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(53,4,'167.179.88.119','2018-12-04 21:12:27','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(54,4,'27.26.7.251','2018-12-04 21:44:06','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(55,6,'113.77.35.195','2018-12-04 21:55:13','Accept:          */*\r\nAccept-Encoding: deflate, gzip\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.94 Safari/537.36\r\n'),(56,6,'14.215.176.141','2018-12-04 22:15:22','Accept:          text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en,*\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nReferer:         http://www.baidu.com/s?wd=diday6\r\nUser-Agent:      Mozilla/5.0 (Windows NT 6.1; WOW64; rv:43.0) Gecko/20100101 Firefox/43.0\r\n'),(57,4,'167.179.88.119','2018-12-04 23:11:49','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(58,4,'167.179.88.119','2018-12-04 23:31:41','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(59,4,'167.179.88.119','2018-12-05 00:37:35','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(60,4,'167.179.88.119','2018-12-05 00:59:21','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n'),(61,4,'167.179.88.119','2018-12-05 09:52:27','Accept-Encoding: gzip\r\nConnection:      Keep-Alive\r\nContent-Length:  \r\nContent-Type:    \r\nHost:            ssr.jkfuns.fun\r\nUser-Agent:      okhttp/3.8.0\r\n');
/*!40000 ALTER TABLE `user_subscribe_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_traffic_daily`
--

DROP TABLE IF EXISTS `user_traffic_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_traffic_daily` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `node_id` int(11) NOT NULL DEFAULT '0' COMMENT '节点ID，0表示统计全部节点',
  `u` bigint(20) NOT NULL DEFAULT '0' COMMENT '上传流量',
  `d` bigint(20) NOT NULL DEFAULT '0' COMMENT '下载流量',
  `total` bigint(20) NOT NULL DEFAULT '0' COMMENT '总流量',
  `traffic` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '总流量（带单位）',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`) USING BTREE,
  KEY `idx_user_node` (`user_id`,`node_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户每日流量统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_traffic_daily`
--

LOCK TABLES `user_traffic_daily` WRITE;
/*!40000 ALTER TABLE `user_traffic_daily` DISABLE KEYS */;
INSERT INTO `user_traffic_daily` VALUES (1,1,0,0,0,0,'0B','2018-12-04 23:50:02','2018-12-04 23:50:02'),(2,1,2,0,0,0,'0B','2018-12-04 23:50:02','2018-12-04 23:50:02'),(3,2,0,0,0,0,'0B','2018-12-04 23:50:02','2018-12-04 23:50:02'),(4,2,2,0,0,0,'0B','2018-12-04 23:50:02','2018-12-04 23:50:02'),(5,3,0,0,0,0,'0B','2018-12-04 23:50:02','2018-12-04 23:50:02'),(6,3,2,0,0,0,'0B','2018-12-04 23:50:02','2018-12-04 23:50:02'),(7,4,0,0,0,0,'0B','2018-12-04 23:50:03','2018-12-04 23:50:03'),(8,4,2,0,0,0,'0B','2018-12-04 23:50:03','2018-12-04 23:50:03'),(9,5,0,0,0,0,'0B','2018-12-04 23:50:03','2018-12-04 23:50:03'),(10,5,2,0,0,0,'0B','2018-12-04 23:50:03','2018-12-04 23:50:03'),(11,6,0,0,0,0,'0B','2018-12-04 23:50:03','2018-12-04 23:50:03'),(12,6,2,0,0,0,'0B','2018-12-04 23:50:03','2018-12-04 23:50:03'),(13,7,0,0,0,0,'0B','2018-12-04 23:50:03','2018-12-04 23:50:03'),(14,7,2,0,0,0,'0B','2018-12-04 23:50:03','2018-12-04 23:50:03');
/*!40000 ALTER TABLE `user_traffic_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_traffic_hourly`
--

DROP TABLE IF EXISTS `user_traffic_hourly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_traffic_hourly` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `node_id` int(11) NOT NULL DEFAULT '0' COMMENT '节点ID，0表示统计全部节点',
  `u` bigint(20) NOT NULL DEFAULT '0' COMMENT '上传流量',
  `d` bigint(20) NOT NULL DEFAULT '0' COMMENT '下载流量',
  `total` bigint(20) NOT NULL DEFAULT '0' COMMENT '总流量',
  `traffic` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '总流量（带单位）',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`) USING BTREE,
  KEY `idx_user_node` (`user_id`,`node_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户每小时流量统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_traffic_hourly`
--

LOCK TABLES `user_traffic_hourly` WRITE;
/*!40000 ALTER TABLE `user_traffic_hourly` DISABLE KEYS */;
INSERT INTO `user_traffic_hourly` VALUES (1,1,0,157411,1628270,1785681,'1.7MB','2018-12-04 17:00:03','2018-12-04 17:00:03'),(3,2,0,0,0,0,'0B','2018-12-04 17:00:03','2018-12-04 17:00:03'),(5,3,0,0,0,0,'0B','2018-12-04 17:00:03','2018-12-04 17:00:03'),(7,4,0,0,0,0,'0B','2018-12-04 17:00:03','2018-12-04 17:00:03'),(9,1,0,182028,1453119,1635147,'1.56MB','2018-12-04 18:00:03','2018-12-04 18:00:03'),(11,2,0,0,0,0,'0B','2018-12-04 18:00:03','2018-12-04 18:00:03'),(13,3,0,0,0,0,'0B','2018-12-04 18:00:03','2018-12-04 18:00:03'),(15,4,0,0,0,0,'0B','2018-12-04 18:00:03','2018-12-04 18:00:03'),(17,1,0,0,0,0,'0B','2018-12-04 19:00:02','2018-12-04 19:00:02'),(18,1,2,0,0,0,'0B','2018-12-04 19:00:02','2018-12-04 19:00:02'),(19,2,0,0,0,0,'0B','2018-12-04 19:00:02','2018-12-04 19:00:02'),(20,2,2,0,0,0,'0B','2018-12-04 19:00:02','2018-12-04 19:00:02'),(21,3,0,0,0,0,'0B','2018-12-04 19:00:03','2018-12-04 19:00:03'),(22,3,2,0,0,0,'0B','2018-12-04 19:00:03','2018-12-04 19:00:03'),(23,4,0,0,0,0,'0B','2018-12-04 19:00:03','2018-12-04 19:00:03'),(24,4,2,0,0,0,'0B','2018-12-04 19:00:03','2018-12-04 19:00:03'),(25,5,0,0,0,0,'0B','2018-12-04 19:00:03','2018-12-04 19:00:03'),(26,5,2,0,0,0,'0B','2018-12-04 19:00:03','2018-12-04 19:00:03'),(27,1,0,0,0,0,'0B','2018-12-04 20:00:03','2018-12-04 20:00:03'),(28,1,2,0,0,0,'0B','2018-12-04 20:00:03','2018-12-04 20:00:03'),(29,2,0,0,0,0,'0B','2018-12-04 20:00:03','2018-12-04 20:00:03'),(30,2,2,0,0,0,'0B','2018-12-04 20:00:03','2018-12-04 20:00:03'),(31,3,0,0,0,0,'0B','2018-12-04 20:00:03','2018-12-04 20:00:03'),(32,3,2,0,0,0,'0B','2018-12-04 20:00:03','2018-12-04 20:00:03'),(33,4,0,0,0,0,'0B','2018-12-04 20:00:03','2018-12-04 20:00:03'),(34,4,2,0,0,0,'0B','2018-12-04 20:00:03','2018-12-04 20:00:03'),(35,5,0,0,0,0,'0B','2018-12-04 20:00:03','2018-12-04 20:00:03'),(36,5,2,0,0,0,'0B','2018-12-04 20:00:03','2018-12-04 20:00:03'),(37,1,0,0,0,0,'0B','2018-12-04 21:00:03','2018-12-04 21:00:03'),(38,1,2,0,0,0,'0B','2018-12-04 21:00:03','2018-12-04 21:00:03'),(39,2,0,0,0,0,'0B','2018-12-04 21:00:03','2018-12-04 21:00:03'),(40,2,2,0,0,0,'0B','2018-12-04 21:00:03','2018-12-04 21:00:03'),(41,3,0,0,0,0,'0B','2018-12-04 21:00:03','2018-12-04 21:00:03'),(42,3,2,0,0,0,'0B','2018-12-04 21:00:03','2018-12-04 21:00:03'),(43,4,0,0,0,0,'0B','2018-12-04 21:00:03','2018-12-04 21:00:03'),(44,4,2,0,0,0,'0B','2018-12-04 21:00:03','2018-12-04 21:00:03'),(45,5,0,0,0,0,'0B','2018-12-04 21:00:03','2018-12-04 21:00:03'),(46,5,2,0,0,0,'0B','2018-12-04 21:00:03','2018-12-04 21:00:03'),(47,1,0,270054,1411327,1681381,'1.6MB','2018-12-04 22:00:03','2018-12-04 22:00:03'),(48,1,2,270054,1411327,1681381,'1.6MB','2018-12-04 22:00:03','2018-12-04 22:00:03'),(49,2,0,0,0,0,'0B','2018-12-04 22:00:03','2018-12-04 22:00:03'),(50,2,2,0,0,0,'0B','2018-12-04 22:00:03','2018-12-04 22:00:03'),(51,3,0,0,0,0,'0B','2018-12-04 22:00:03','2018-12-04 22:00:03'),(52,3,2,0,0,0,'0B','2018-12-04 22:00:03','2018-12-04 22:00:03'),(53,4,0,599258,61104150,61703408,'58.84MB','2018-12-04 22:00:03','2018-12-04 22:00:03'),(54,4,2,599258,61104150,61703408,'58.84MB','2018-12-04 22:00:03','2018-12-04 22:00:03'),(55,5,0,0,0,0,'0B','2018-12-04 22:00:03','2018-12-04 22:00:03'),(56,5,2,0,0,0,'0B','2018-12-04 22:00:03','2018-12-04 22:00:03'),(57,6,0,0,0,0,'0B','2018-12-04 22:00:03','2018-12-04 22:00:03'),(58,6,2,0,0,0,'0B','2018-12-04 22:00:03','2018-12-04 22:00:03'),(59,1,0,0,0,0,'0B','2018-12-04 23:00:03','2018-12-04 23:00:03'),(60,1,2,0,0,0,'0B','2018-12-04 23:00:03','2018-12-04 23:00:03'),(61,2,0,0,0,0,'0B','2018-12-04 23:00:03','2018-12-04 23:00:03'),(62,2,2,0,0,0,'0B','2018-12-04 23:00:03','2018-12-04 23:00:03'),(63,3,0,0,0,0,'0B','2018-12-04 23:00:03','2018-12-04 23:00:03'),(64,3,2,0,0,0,'0B','2018-12-04 23:00:03','2018-12-04 23:00:03'),(65,4,0,427972,63829033,64257005,'61.28MB','2018-12-04 23:00:03','2018-12-04 23:00:03'),(66,4,2,427972,63829033,64257005,'61.28MB','2018-12-04 23:00:03','2018-12-04 23:00:03'),(67,5,0,0,0,0,'0B','2018-12-04 23:00:03','2018-12-04 23:00:03'),(68,5,2,0,0,0,'0B','2018-12-04 23:00:03','2018-12-04 23:00:03'),(69,6,0,1705,170081,171786,'167.76KB','2018-12-04 23:00:03','2018-12-04 23:00:03'),(70,6,2,1705,170081,171786,'167.76KB','2018-12-04 23:00:03','2018-12-04 23:00:03'),(71,7,0,0,0,0,'0B','2018-12-04 23:00:03','2018-12-04 23:00:03'),(72,7,2,0,0,0,'0B','2018-12-04 23:00:03','2018-12-04 23:00:03'),(73,1,0,0,0,0,'0B','2018-12-05 00:00:03','2018-12-05 00:00:03'),(74,1,2,0,0,0,'0B','2018-12-05 00:00:03','2018-12-05 00:00:03'),(75,2,0,0,0,0,'0B','2018-12-05 00:00:03','2018-12-05 00:00:03'),(76,2,2,0,0,0,'0B','2018-12-05 00:00:03','2018-12-05 00:00:03'),(77,3,0,0,0,0,'0B','2018-12-05 00:00:03','2018-12-05 00:00:03'),(78,3,2,0,0,0,'0B','2018-12-05 00:00:03','2018-12-05 00:00:03'),(79,4,0,2120988,228987553,231108541,'220.4MB','2018-12-05 00:00:03','2018-12-05 00:00:03'),(80,4,2,2120988,228987553,231108541,'220.4MB','2018-12-05 00:00:03','2018-12-05 00:00:03'),(81,5,0,0,0,0,'0B','2018-12-05 00:00:03','2018-12-05 00:00:03'),(82,5,2,0,0,0,'0B','2018-12-05 00:00:03','2018-12-05 00:00:03'),(83,6,0,0,0,0,'0B','2018-12-05 00:00:03','2018-12-05 00:00:03'),(84,6,2,0,0,0,'0B','2018-12-05 00:00:03','2018-12-05 00:00:03'),(85,7,0,0,0,0,'0B','2018-12-05 00:00:03','2018-12-05 00:00:03'),(86,7,2,0,0,0,'0B','2018-12-05 00:00:03','2018-12-05 00:00:03'),(87,1,0,0,0,0,'0B','2018-12-05 01:00:03','2018-12-05 01:00:03'),(88,1,2,0,0,0,'0B','2018-12-05 01:00:03','2018-12-05 01:00:03'),(89,2,0,0,0,0,'0B','2018-12-05 01:00:03','2018-12-05 01:00:03'),(90,2,2,0,0,0,'0B','2018-12-05 01:00:03','2018-12-05 01:00:03'),(91,3,0,0,0,0,'0B','2018-12-05 01:00:03','2018-12-05 01:00:03'),(92,3,2,0,0,0,'0B','2018-12-05 01:00:03','2018-12-05 01:00:03'),(93,4,0,2070877,26032985,28103862,'26.8MB','2018-12-05 01:00:03','2018-12-05 01:00:03'),(94,4,2,2070877,26032985,28103862,'26.8MB','2018-12-05 01:00:03','2018-12-05 01:00:03'),(95,5,0,0,0,0,'0B','2018-12-05 01:00:03','2018-12-05 01:00:03'),(96,5,2,0,0,0,'0B','2018-12-05 01:00:03','2018-12-05 01:00:03'),(97,6,0,0,0,0,'0B','2018-12-05 01:00:03','2018-12-05 01:00:03'),(98,6,2,0,0,0,'0B','2018-12-05 01:00:03','2018-12-05 01:00:03'),(99,7,0,0,0,0,'0B','2018-12-05 01:00:03','2018-12-05 01:00:03'),(100,7,2,0,0,0,'0B','2018-12-05 01:00:03','2018-12-05 01:00:03'),(101,1,0,0,0,0,'0B','2018-12-05 02:00:02','2018-12-05 02:00:02'),(102,1,2,0,0,0,'0B','2018-12-05 02:00:02','2018-12-05 02:00:02'),(103,2,0,0,0,0,'0B','2018-12-05 02:00:02','2018-12-05 02:00:02'),(104,2,2,0,0,0,'0B','2018-12-05 02:00:02','2018-12-05 02:00:02'),(105,3,0,0,0,0,'0B','2018-12-05 02:00:02','2018-12-05 02:00:02'),(106,3,2,0,0,0,'0B','2018-12-05 02:00:02','2018-12-05 02:00:02'),(107,4,0,121748,405078,526826,'514.48KB','2018-12-05 02:00:02','2018-12-05 02:00:02'),(108,4,2,121748,405078,526826,'514.48KB','2018-12-05 02:00:02','2018-12-05 02:00:02'),(109,5,0,0,0,0,'0B','2018-12-05 02:00:02','2018-12-05 02:00:02'),(110,5,2,0,0,0,'0B','2018-12-05 02:00:02','2018-12-05 02:00:02'),(111,6,0,0,0,0,'0B','2018-12-05 02:00:02','2018-12-05 02:00:02'),(112,6,2,0,0,0,'0B','2018-12-05 02:00:02','2018-12-05 02:00:02'),(113,7,0,0,0,0,'0B','2018-12-05 02:00:02','2018-12-05 02:00:02'),(114,7,2,0,0,0,'0B','2018-12-05 02:00:02','2018-12-05 02:00:02'),(115,1,0,516908,2988055,3504963,'3.34MB','2018-12-05 03:00:02','2018-12-05 03:00:02'),(116,1,2,516908,2988055,3504963,'3.34MB','2018-12-05 03:00:02','2018-12-05 03:00:02'),(117,2,0,0,0,0,'0B','2018-12-05 03:00:02','2018-12-05 03:00:02'),(118,2,2,0,0,0,'0B','2018-12-05 03:00:02','2018-12-05 03:00:02'),(119,3,0,0,0,0,'0B','2018-12-05 03:00:02','2018-12-05 03:00:02'),(120,3,2,0,0,0,'0B','2018-12-05 03:00:02','2018-12-05 03:00:02'),(121,4,0,0,0,0,'0B','2018-12-05 03:00:02','2018-12-05 03:00:02'),(122,4,2,0,0,0,'0B','2018-12-05 03:00:02','2018-12-05 03:00:02'),(123,5,0,0,0,0,'0B','2018-12-05 03:00:02','2018-12-05 03:00:02'),(124,5,2,0,0,0,'0B','2018-12-05 03:00:02','2018-12-05 03:00:02'),(125,6,0,0,0,0,'0B','2018-12-05 03:00:02','2018-12-05 03:00:02'),(126,6,2,0,0,0,'0B','2018-12-05 03:00:03','2018-12-05 03:00:03'),(127,7,0,0,0,0,'0B','2018-12-05 03:00:03','2018-12-05 03:00:03'),(128,7,2,0,0,0,'0B','2018-12-05 03:00:03','2018-12-05 03:00:03'),(129,1,0,57000,2259018,2316018,'2.21MB','2018-12-05 04:00:03','2018-12-05 04:00:03'),(130,1,2,57000,2259018,2316018,'2.21MB','2018-12-05 04:00:03','2018-12-05 04:00:03'),(131,2,0,0,0,0,'0B','2018-12-05 04:00:03','2018-12-05 04:00:03'),(132,2,2,0,0,0,'0B','2018-12-05 04:00:03','2018-12-05 04:00:03'),(133,3,0,0,0,0,'0B','2018-12-05 04:00:03','2018-12-05 04:00:03'),(134,3,2,0,0,0,'0B','2018-12-05 04:00:03','2018-12-05 04:00:03'),(135,4,0,0,0,0,'0B','2018-12-05 04:00:03','2018-12-05 04:00:03'),(136,4,2,0,0,0,'0B','2018-12-05 04:00:03','2018-12-05 04:00:03'),(137,5,0,0,0,0,'0B','2018-12-05 04:00:03','2018-12-05 04:00:03'),(138,5,2,0,0,0,'0B','2018-12-05 04:00:03','2018-12-05 04:00:03'),(139,6,0,0,0,0,'0B','2018-12-05 04:00:03','2018-12-05 04:00:03'),(140,6,2,0,0,0,'0B','2018-12-05 04:00:03','2018-12-05 04:00:03'),(141,7,0,0,0,0,'0B','2018-12-05 04:00:03','2018-12-05 04:00:03'),(142,7,2,0,0,0,'0B','2018-12-05 04:00:03','2018-12-05 04:00:03'),(143,1,0,7665,17813,25478,'24.88KB','2018-12-05 05:00:02','2018-12-05 05:00:02'),(144,1,2,7665,17813,25478,'24.88KB','2018-12-05 05:00:02','2018-12-05 05:00:02'),(145,2,0,0,0,0,'0B','2018-12-05 05:00:02','2018-12-05 05:00:02'),(146,2,2,0,0,0,'0B','2018-12-05 05:00:02','2018-12-05 05:00:02'),(147,3,0,0,0,0,'0B','2018-12-05 05:00:02','2018-12-05 05:00:02'),(148,3,2,0,0,0,'0B','2018-12-05 05:00:02','2018-12-05 05:00:02'),(149,4,0,0,0,0,'0B','2018-12-05 05:00:02','2018-12-05 05:00:02'),(150,4,2,0,0,0,'0B','2018-12-05 05:00:02','2018-12-05 05:00:02'),(151,5,0,0,0,0,'0B','2018-12-05 05:00:02','2018-12-05 05:00:02'),(152,5,2,0,0,0,'0B','2018-12-05 05:00:02','2018-12-05 05:00:02'),(153,6,0,0,0,0,'0B','2018-12-05 05:00:02','2018-12-05 05:00:02'),(154,6,2,0,0,0,'0B','2018-12-05 05:00:02','2018-12-05 05:00:02'),(155,7,0,0,0,0,'0B','2018-12-05 05:00:02','2018-12-05 05:00:02'),(156,7,2,0,0,0,'0B','2018-12-05 05:00:02','2018-12-05 05:00:02'),(157,1,0,10027,22981,33008,'32.23KB','2018-12-05 06:00:02','2018-12-05 06:00:02'),(158,1,2,10027,22981,33008,'32.23KB','2018-12-05 06:00:02','2018-12-05 06:00:02'),(159,2,0,0,0,0,'0B','2018-12-05 06:00:02','2018-12-05 06:00:02'),(160,2,2,0,0,0,'0B','2018-12-05 06:00:02','2018-12-05 06:00:02'),(161,3,0,0,0,0,'0B','2018-12-05 06:00:02','2018-12-05 06:00:02'),(162,3,2,0,0,0,'0B','2018-12-05 06:00:02','2018-12-05 06:00:02'),(163,4,0,0,0,0,'0B','2018-12-05 06:00:02','2018-12-05 06:00:02'),(164,4,2,0,0,0,'0B','2018-12-05 06:00:02','2018-12-05 06:00:02'),(165,5,0,0,0,0,'0B','2018-12-05 06:00:02','2018-12-05 06:00:02'),(166,5,2,0,0,0,'0B','2018-12-05 06:00:02','2018-12-05 06:00:02'),(167,6,0,0,0,0,'0B','2018-12-05 06:00:02','2018-12-05 06:00:02'),(168,6,2,0,0,0,'0B','2018-12-05 06:00:02','2018-12-05 06:00:02'),(169,7,0,0,0,0,'0B','2018-12-05 06:00:02','2018-12-05 06:00:02'),(170,7,2,0,0,0,'0B','2018-12-05 06:00:02','2018-12-05 06:00:02'),(171,1,0,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(172,1,2,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(173,2,0,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(174,2,2,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(175,3,0,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(176,3,2,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(177,4,0,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(178,4,2,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(179,5,0,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(180,5,2,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(181,6,0,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(182,6,2,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(183,7,0,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(184,7,2,0,0,0,'0B','2018-12-05 07:00:03','2018-12-05 07:00:03'),(185,1,0,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(186,1,2,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(187,2,0,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(188,2,2,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(189,3,0,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(190,3,2,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(191,4,0,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(192,4,2,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(193,5,0,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(194,5,2,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(195,6,0,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(196,6,2,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(197,7,0,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(198,7,2,0,0,0,'0B','2018-12-05 08:00:03','2018-12-05 08:00:03'),(199,1,0,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(200,1,2,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(201,2,0,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(202,2,2,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(203,3,0,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(204,3,2,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(205,4,0,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(206,4,2,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(207,5,0,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(208,5,2,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(209,6,0,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(210,6,2,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(211,7,0,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(212,7,2,0,0,0,'0B','2018-12-05 09:00:03','2018-12-05 09:00:03'),(213,1,0,0,0,0,'0B','2018-12-05 10:00:02','2018-12-05 10:00:02'),(214,1,2,0,0,0,'0B','2018-12-05 10:00:02','2018-12-05 10:00:02'),(215,2,0,0,0,0,'0B','2018-12-05 10:00:02','2018-12-05 10:00:02'),(216,2,2,0,0,0,'0B','2018-12-05 10:00:02','2018-12-05 10:00:02'),(217,3,0,0,0,0,'0B','2018-12-05 10:00:02','2018-12-05 10:00:02'),(218,3,2,0,0,0,'0B','2018-12-05 10:00:02','2018-12-05 10:00:02'),(219,4,0,148441,2649091,2797532,'2.67MB','2018-12-05 10:00:02','2018-12-05 10:00:02'),(220,4,2,148441,2649091,2797532,'2.67MB','2018-12-05 10:00:02','2018-12-05 10:00:02'),(221,5,0,0,0,0,'0B','2018-12-05 10:00:02','2018-12-05 10:00:02'),(222,5,2,0,0,0,'0B','2018-12-05 10:00:02','2018-12-05 10:00:02'),(223,6,0,0,0,0,'0B','2018-12-05 10:00:02','2018-12-05 10:00:02'),(224,6,2,0,0,0,'0B','2018-12-05 10:00:02','2018-12-05 10:00:02'),(225,7,0,0,0,0,'0B','2018-12-05 10:00:02','2018-12-05 10:00:02'),(226,7,2,0,0,0,'0B','2018-12-05 10:00:02','2018-12-05 10:00:02'),(227,1,0,0,0,0,'0B','2018-12-05 11:00:03','2018-12-05 11:00:03'),(228,1,2,0,0,0,'0B','2018-12-05 11:00:03','2018-12-05 11:00:03'),(229,2,0,0,0,0,'0B','2018-12-05 11:00:03','2018-12-05 11:00:03'),(230,2,2,0,0,0,'0B','2018-12-05 11:00:03','2018-12-05 11:00:03'),(231,3,0,0,0,0,'0B','2018-12-05 11:00:03','2018-12-05 11:00:03'),(232,3,2,0,0,0,'0B','2018-12-05 11:00:03','2018-12-05 11:00:03'),(233,4,0,88035,857417,945452,'923.29KB','2018-12-05 11:00:03','2018-12-05 11:00:03'),(234,4,2,88035,857417,945452,'923.29KB','2018-12-05 11:00:03','2018-12-05 11:00:03'),(235,5,0,0,0,0,'0B','2018-12-05 11:00:03','2018-12-05 11:00:03'),(236,5,2,0,0,0,'0B','2018-12-05 11:00:03','2018-12-05 11:00:03'),(237,6,0,0,0,0,'0B','2018-12-05 11:00:03','2018-12-05 11:00:03'),(238,6,2,0,0,0,'0B','2018-12-05 11:00:03','2018-12-05 11:00:03'),(239,7,0,0,0,0,'0B','2018-12-05 11:00:03','2018-12-05 11:00:03'),(240,7,2,0,0,0,'0B','2018-12-05 11:00:03','2018-12-05 11:00:03');
/*!40000 ALTER TABLE `user_traffic_hourly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_traffic_log`
--

DROP TABLE IF EXISTS `user_traffic_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_traffic_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `u` int(11) NOT NULL DEFAULT '0' COMMENT '上传流量',
  `d` int(11) NOT NULL DEFAULT '0' COMMENT '下载流量',
  `node_id` int(11) NOT NULL DEFAULT '0' COMMENT '节点ID',
  `rate` float NOT NULL COMMENT '流量比例',
  `traffic` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '产生流量',
  `log_time` int(11) NOT NULL COMMENT '记录时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_node` (`node_id`),
  KEY `idx_user_node` (`user_id`,`node_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户流量日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_traffic_log`
--

LOCK TABLES `user_traffic_log` WRITE;
/*!40000 ALTER TABLE `user_traffic_log` DISABLE KEYS */;
INSERT INTO `user_traffic_log` VALUES (4,1,270054,1411327,2,1,'1641.97KB',1543928783),(5,4,134233,843484,2,1,'954.8KB',1543929203),(6,4,333301,42501925,2,1,'40.85MB',1543929683),(7,4,32770,17349072,2,1,'16.58MB',1543929743),(8,4,98954,409669,2,1,'496.7KB',1543931304),(9,6,1705,170081,2,1,'167.76KB',1543933525),(10,4,164013,15413415,2,1,'14.86MB',1543934906),(11,4,170303,23893167,2,1,'22.95MB',1543934966),(12,4,93656,24522451,2,1,'23.48MB',1543935026),(13,4,211764,1060931,2,1,'1242.87KB',1543935867),(14,4,290453,1180848,2,1,'1436.82KB',1543936887),(15,4,134816,3104455,2,1,'3.09MB',1543937488),(16,4,108820,25606896,2,1,'24.52MB',1543937548),(17,4,30546,7832739,2,1,'7.5MB',1543937608),(18,4,20489,8980008,2,1,'8.58MB',1543937668),(19,4,15114,6462130,2,1,'6.18MB',1543937728),(20,4,117348,7421670,2,1,'7.19MB',1543937848),(21,4,68450,11649852,2,1,'11.18MB',1543937908),(22,4,167762,3928308,2,1,'3.91MB',1543937968),(23,4,129400,14271415,2,1,'13.73MB',1543938028),(24,4,105857,32904221,2,1,'31.48MB',1543938148),(25,4,192020,8272234,2,1,'8.07MB',1543938328),(26,4,71396,24738500,2,1,'23.66MB',1543938388),(27,4,25848,10979404,2,1,'10.5MB',1543938448),(28,4,17250,8317792,2,1,'7.95MB',1543938508),(29,4,18341,8086087,2,1,'7.73MB',1543938568),(30,4,22193,6853534,2,1,'6.56MB',1543938628),(31,4,22103,7687993,2,1,'7.35MB',1543938688),(32,4,104526,13811363,2,1,'13.27MB',1543938748),(33,4,111893,6449630,2,1,'6.26MB',1543938808),(34,4,19259,7342299,2,1,'7.02MB',1543938868),(35,4,115340,2045244,2,1,'2.06MB',1543938988),(36,4,123418,1580634,2,1,'1664.11KB',1543939889),(37,4,297147,4234691,2,1,'4.32MB',1543941510),(38,4,204239,10854991,2,1,'10.55MB',1543941570),(39,4,308355,2280468,2,1,'2.47MB',1543941690),(40,4,384862,2505421,2,1,'2.76MB',1543941870),(41,4,481189,2587473,2,1,'2.93MB',1543941990),(42,4,271667,1989307,2,1,'2.16MB',1543942410),(43,4,121748,405078,2,1,'514.48KB',1543943911),(44,1,423038,2307171,2,1,'2.6MB',1543947753),(45,1,93870,680884,2,1,'756.6KB',1543949074),(46,1,57000,2259018,2,1,'2.21MB',1543953036),(47,1,7665,17813,2,1,'24.88KB',1543955018),(48,1,10027,22981,2,1,'32.23KB',1543957479),(49,4,148441,2649091,2,1,'2.67MB',1543974769),(50,4,88035,857417,2,1,'923.29KB',1543975909);
/*!40000 ALTER TABLE `user_traffic_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_traffic_modify_log`
--

DROP TABLE IF EXISTS `user_traffic_modify_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_traffic_modify_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `order_id` int(11) NOT NULL DEFAULT '0' COMMENT '发生的订单ID',
  `before` bigint(20) NOT NULL DEFAULT '0' COMMENT '操作前流量',
  `after` bigint(20) NOT NULL DEFAULT '0' COMMENT '操作后流量',
  `desc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '描述',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户流量变动日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_traffic_modify_log`
--

LOCK TABLES `user_traffic_modify_log` WRITE;
/*!40000 ALTER TABLE `user_traffic_modify_log` DISABLE KEYS */;
INSERT INTO `user_traffic_modify_log` VALUES (1,1,0,1073741824000,1073741824000,'后台手动编辑用户','2018-12-04 15:57:34','2018-12-04 15:57:34'),(2,1,1,1073741824000,1074815565824,'[余额支付]用户购买商品，加上流量','2018-12-04 15:59:25','2018-12-04 15:59:25'),(3,2,0,1073741824,1073741824,'后台手动编辑用户','2018-12-04 16:09:18','2018-12-04 16:09:18'),(4,3,0,1073741824,1073741824,'后台手动编辑用户','2018-12-04 16:42:24','2018-12-04 16:42:24'),(5,1,6,1074815565824,1074826051584,'[在线支付]用户购买商品，加上流量','2018-12-04 16:59:52','2018-12-04 16:59:52'),(6,1,0,1074826051584,1074826051584,'后台手动编辑用户','2018-12-04 17:18:56','2018-12-04 17:18:56'),(7,5,0,0,1073741824000,'后台手动添加用户','2018-12-04 18:28:20','2018-12-04 18:28:20'),(8,5,0,1073741824000,1073741824000,'后台手动编辑用户','2018-12-04 19:29:49','2018-12-04 19:29:49'),(9,4,0,1073741824,1073741824,'后台手动编辑用户','2018-12-04 20:54:59','2018-12-04 20:54:59'),(10,4,0,1073741824,1073741824,'后台手动编辑用户','2018-12-04 21:04:31','2018-12-04 21:04:31');
/*!40000 ALTER TABLE `user_traffic_modify_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verify`
--

DROP TABLE IF EXISTS `verify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '激活类型：1-自行激活、2-管理员激活',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `token` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '校验token',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态：0-未使用、1-已使用、2-已失效',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='账号激活邮件地址';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verify`
--

LOCK TABLES `verify` WRITE;
/*!40000 ALTER TABLE `verify` DISABLE KEYS */;
INSERT INTO `verify` VALUES (1,1,2,'1b235f3fce3b310c886e33b29c0b5942',0,'2018-12-04 16:05:55','2018-12-04 16:05:55'),(2,1,3,'8166727a05d0d9080dffe21a5e5ce827',0,'2018-12-04 16:09:43','2018-12-04 16:09:43'),(3,1,3,'78810ead78dcc9c2c1c2e7c59bb7c770',0,'2018-12-04 16:13:06','2018-12-04 16:13:06'),(4,1,4,'9d31bd507769163dda614250cf7ba85c',1,'2018-12-04 16:19:30','2018-12-04 16:19:49'),(5,1,6,'baeeac7213215d07d64abf69267f5b28',1,'2018-12-04 21:52:30','2018-12-04 21:53:18'),(6,1,7,'970993663c36b4646531320b377000c0',1,'2018-12-04 22:22:36','2018-12-04 22:22:57');
/*!40000 ALTER TABLE `verify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verify_code`
--

DROP TABLE IF EXISTS `verify_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verify_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户邮箱',
  `code` char(6) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '验证码',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态：0-未使用、1-已使用、2-已失效',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='注册激活验证码';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verify_code`
--

LOCK TABLES `verify_code` WRITE;
/*!40000 ALTER TABLE `verify_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `verify_code` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-05 11:22:27
